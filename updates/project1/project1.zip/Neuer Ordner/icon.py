from Pillow import Image, ImageDraw, ImageFont

# Create a blank image with white background
image_size = (512, 512)
background_color = (34, 139, 34)  # Dark green to represent a poker table
image = Image.new('RGB', image_size, background_color)
draw = ImageDraw.Draw(image)

# Define the digital timer area
timer_position = (100, 50)
timer_size = (312, 100)
timer_color = (0, 0, 255)  # Blue
draw.rectangle([timer_position, (timer_position[0] + timer_size[0], timer_position[1] + timer_size[1])], fill=timer_color)

# Add the digital timer text
timer_text = "00:00"
font = ImageFont.truetype("arial.ttf", 70)
text_size = draw.textsize(timer_text, font=font)
text_position = (timer_position[0] + (timer_size[0] - text_size[0]) / 2, timer_position[1] + (timer_size[1] - text_size[1]) / 2)
draw.text(text_position, timer_text, font=font, fill=(255, 255, 255))

# Define the poker cards
card_width = 70
card_height = 100
card_gap = 10
start_x = (image_size[0] - (card_width * 4 + card_gap * 3)) // 2
start_y = timer_position[1] + timer_size[1] + 50
cards = ['10', 'J', 'Q', 'K', 'A']
suit = '♠'
font = ImageFont.truetype("arial.ttf", 40)

for i, card in enumerate(cards):
    x = start_x + i * (card_width + card_gap)
    y = start_y
    draw.rectangle([x, y, x + card_width, y + card_height], fill=(255, 255, 255), outline=(0, 0, 0))
    card_text = f"{card}{suit}"
    text_size = draw.textsize(card_text, font=font)
    text_position = (x + (card_width - text_size[0]) / 2, y + (card_height - text_size[1]) / 2)
    draw.text(text_position, card_text, font=font, fill=(0, 0, 0))

# Save the image
image.save("poker_timer_icon.png")
image.show()