let cmdText = "";

function bClick(id) {
  if (id.id === "Forward") {
    document.querySelector(".cmdInput").value = "LevelPlus";
  } else if (id.id === "Back") {
    document.querySelector(".cmdInput").value = "LevelMinus";
  } else if (id.id === "Timer" && id.value === "Start") {
    document.querySelector(".cmdInput").value = "Start";
    id.value = "Pause";
  } else if (id.id === "Timer" && id.value === "Pause") {
    document.querySelector(".cmdInput").value = "Pause";
    id.value = "Start";
  } else  if (id.id === "ShowBtn" && id.value === "Show") {
    document.querySelector(".cmdInput").value = "Show";
    id.value = "Hide";
  } else if (id.id === "ShowBtn" && id.value === "Hide") {
    document.querySelector(".cmdInput").value = "Hide";
    id.value = "Show";
  } else if (id.id === "PlayerMinus") {
    document.querySelector(".cmdInput").value = "PlayerMinus";
  } else if (id.id === "PlayerPlus") {
    document.querySelector(".cmdInput").value = "PlayerPlus";
  } else if (id.id === "Update") {
    document.querySelector(".cmdInput").value = "Update";
  } else if (id.id === "AddOnMinus") {
    document.querySelector(".cmdInput").value = "AddOnMinus";
  } else if (id.id === "AddOnPlus") {
    document.querySelector(".cmdInput").value = "AddOnPlus";
  } else if (id.id === "ReBuyMinus") {
    document.querySelector(".cmdInput").value = "ReBuyMinus";
  } else if (id.id === "ReBuyPlus") {
    document.querySelector(".cmdInput").value = "ReBuyPlus";
  } else if (id.id === "mainEvent") {
    document.querySelector(".cmdInput").value = "MainEvent";
  } else if (id.id === "singleTable") {
    document.querySelector(".cmdInput").value = "SingleTable";
  } else if (id.id === "Undo") {
    document.querySelector(".cmdInput").value = "Undo";
  } else if (id.id === "BackToIndex") {
    document.querySelector(".cmdInput").value = "BackToIndex";
  } else if (id.id === "BackToQuery") {
    document.querySelector(".cmdInput").value = "BackToQuery";
  } else if (id.id === "Search") {
    document.querySelector(".cmdInput").value = "Search";
  } else if (id.id === "Reset") {
    document.querySelector(".cmdInput").value = "Reset";
  }

  document.querySelector(".formSubmit").click();
}

function bClickTable(id) {
  document.querySelector(".cmdInput").value = id.id;
}

function bClickTableSeats(id) {
  document.querySelector(".cmdSeats").value = id.id;
}
