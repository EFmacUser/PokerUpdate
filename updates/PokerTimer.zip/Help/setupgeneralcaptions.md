<link href="styles/styles.css" rel="stylesheet"></link>

# Dialog „Einstellungen“

![Dialog Einstellungen](img/setupcaptions.jpg)

Hier können generelle Einstellungen für das Programm gemacht werden. Der Aufruf ist auch mit „Alt“ (Windows) bzw. „Cmd“ (Mac) und Taste Komma (,) möglich.
Da die Timer-Panels nicht modal laufen, kann der Einstellungen-Dialog parallel aufgerufen werden. So ist es möglich, insbesondere die Farben anzupassen und das Ergebnis sofort im jeweiligen Timer-Panel zu sehen. Ebenso können dann gleich auch die Töne für Blind-Wechsel etc. geändert werden, ohne dass das Turnier bzw. der Single-Table unterbrochen werden muss.

## Gruppe „Allgemein - Beschriftung - Coins“

Da die Wertmarken (= Coins) bei den einzelnen Turnier-Ausrichtern unterschiedliche Werte haben können, besteht hier die Möglichkeit, diese anzupassen. Diese Werte werden an zwei Stellen im Programm genutzt:

* Turnier-Einstellungen -> Tab „Spieler“:Hier wird erfasst wie der Spieler sein Buy-In entrichtet hat. Dies kann auch mit Coins erfolgen, so dass diese hier erfasst werden. Die Spalten für die Coins tragen die Werte des jeweiligen Coins, so dass diese Spaltenbeschriftung entsprechend angepasst werden muss.
* „Auswertungen“ -> Bereich „Turnier-Daten“:Bei Auswahl des Berichtes „Liste der gemeldeten Spieler“ wird ebenfalls mit ausgegeben, wie der Spieler sein Buy-In bezahlt hat. Auch bei der Abrechnung eines Turniers und Ausdruck des Berichts „Abrechnung der Kasse des Turniers“ müssen die Werte der Coins angedruckt werden. Dementsprechend werden auch hier die Spalten-Beschriftungen der Coins mit den hier erfassten Werten ausgegeben.

## Gruppe „Allgemein - Beschriftung - Nachname“

In verschiedenen Dialogen wird der Nachname nur gekürzt angezeigt bzw. es kann gewählt werden, ob der Nachname vollständig oder gekürzt angezeigt werden soll. Sofern er gekürzt angezeigt wird, kann an dieser Stelle programmweit gültig eingestellt werden, aus wie vielen Buchstaben der Nachname noch bestehen soll. Die Mindestlänge ist "1".
