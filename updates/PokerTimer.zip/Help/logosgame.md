<link href="styles/styles.css" rel="stylesheet"></link>

# „Logo“

![Logos](img/logos.jpg)

Sofern über Allgemein-> „Logos verwalten …“ entsprechende Logos hinterlegt wurden, kann an dieser Stelle für dieses Turnier-Set eines ausgewählt werden. Das Handling ist simpel:

* Doppelklick auf einen Eintrag in der Liste der möglichen Logos transferiert dieses in das Feld „Gewähltes Logo“.
* Umgekehrt löscht ein Doppelklick im Feld „Gewähltes Logo“ dieses wieder und führt es zurück in die Liste der möglichen Logos.
