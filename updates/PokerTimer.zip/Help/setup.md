<link href="styles/styles.css" rel="stylesheet"></link>

# Dialog „Einstellungen“

![Dialog Einstellungen](img/setup.jpg)

Hier können generelle Einstellungen für das Programm gemacht werden. Der Aufruf ist auch mit „Alt“ (Windows) bzw. „Cmd“ (Mac) und Taste Komma (,) möglich.
Da die Timer-Panels nicht modal laufen, kann der Einstellungen-Dialog parallel aufgerufen werden. So ist es möglich, insbesondere die Farben anzupassen und das Ergebnis sofort im jeweiligen Timer-Panel zu sehen. Ebenso können dann gleich auch die Töne für Blind-Wechsel etc. geändert werden, ohne dass das Turnier bzw. der Single-Table unterbrochen werden muss.

## Gruppe „Hinweis-Töne“

Bislang sind die auswählbaren Sounds zwar übersichtlich, aber diese können nun frei den drei Ereignissen zugeordnet werden:

* Blind-Wechsel: Bei jeder Änderung der Blind-Stufe wird dieser Sound abgespielt.
* Minute: Mit diesem Sound wird die letzte Minute der Blind-Stufe angekündigt.
* Sekunde: Dieser Sound wird jeweils bei den letzten fünf Sekunden der Blind-Stufe abgespielt.
Über den Button „Reset“ werden die Standard-Töne für das Timer-Panel wiederhergestellt. Die vorherigen Einstellungen gehen dabei verloren, auch wenn man den Dialog über Button „Abbruch“ verlässt.

## Gruppe „Coins“

Da die Wertmarken (= Coins) bei den einzelnen Turnier-Ausrichtern unterschiedliche Werte haben können, besteht hier die Möglichkeit, diese anzupassen. Diese Werte werden an zwei Stellen im Programm genutzt:

* Turnier-Einstellungen -> Tab „Spieler“:Hier wird erfasst wie der Spieler sein Buy-In entrichtet hat. Dies kann auch mit Coins erfolgen, so dass diese hier erfasst werden. Die Spalten für die Coins tragen die Werte des jeweiligen Coins, so dass diese Spaltenbeschriftung entsprechend angepasst werden muss.
* „Auswertungen“ -> Bereich „Turnier-Daten“:Bei Auswahl des Berichtes „Liste der gemeldeten Spieler“ wird ebenfalls mit ausgegeben, wie der Spieler sein Buy-In bezahlt hat. Auch bei der Abrechnung eines Turniers und Ausdruck des Berichts „Abrechnung der Kasse des Turniers“ müssen die Werte der Coins angedruckt werden. Dementsprechend werden auch hier die Spalten-Beschriftungen der Coins mit den hier erfassten Werten ausgegeben.

## Gruppe „Timer-Panel - Farben“

Im bescheidenen Umfang kann man an dieser Stelle die Farben für verschiedene Elemente der Timer-Panels einstellen.
Über den Button „Reset“ werden die Standard-Farben für das jeweilige Timer-Panel wiederhergestellt. Die vorherigen Einstellungen gehen dabei verloren, auch wenn man den Dialog anschließend über Button „Abbruch“ verlässt.

## Gruppe „Timer-Panel - Auswahl Bildschirm“

Sofern am System mehr als ein Monitor angeschlossen ist, kann hiermit standardmäßig vorgegeben, auf welchem Monitor beim Start die Timer-Panels angezeigt werden sollen. In der Regel bietet sich hier die Auswahl eines Beamers an.
Über den Button „Update“ kann die Liste der verfügbaren Monitore aktualisiert werden, um Monitore zu ergänzen, die erst nach dem Start des Einstellungen-Dialogs angeschlossen worden sind.
Wenn das jeweilige Timer-Panel gestartet wurde, kann das Fenster aber auch manuell auf einen der vorhandenen Monitore gezogen werden. Das Timer-Panel merkt sich den Monitor für den nächsten Start. Sollte dann nur noch ein Monitor vorhanden sein (z.B. Beamer wurde noch nicht angeschlossen) wird standardmäßig wieder auf dem Primär-Monitor ausgegeben.

## Gruppe „Spracheinstellungen“

Im Programm können - als Spielerei - sämtliche Dialoge sowohl in Deutsch als auch in Englisch dargestellt werden. Einzig auf dem Timer-Panel bleiben die Anzeigen immer in Englisch. Hier werden lediglich die Mouse-over-Hilfetexte übersetzt.
Hingegen werden auch die „Auswertungen“, also insbesondere die Überschriften der Berichte, entsprechend übersetzt.

***Einschränkung***: Leider wird bei Umstellung von Deutsch auf Englisch in der Mac-Version eine Fehlermeldung „Access Violation“ angezeigt.

***Workaround***: Die Fehlermeldung kann einfach mit „OK“ bestätigt werden, das Programm arbeitet ansonsten dennoch fehlerfrei weiter.

## Gruppe „Web-Server“

Der im PokerTimer integrierte Web-Server ist standardmäßig darauf eingestellt, über den Port 8888 Befehle entgegen zu nehmen. Sollte dieser Port von einem anderen Programm benutzt werden, kann der Port hier beliebig geändert werden.
Damit der Web-Server über den neuen Port erreichbar ist, muss der PokerTimer nach einer Änderung aber erst neu gestartet werden.
Die IP-Adresse des Rechners, auf dem der PokerTimer und damit auch der Web-Server laufen, wird vom Programm automatisch bei Programmstart ermittelt. Das manuelle Anstoßen der Suche über den Button „Update“ sollte nur in Ausnahmefällen nötig sein. Eine manuelle Erfassung hingegen ist nicht möglich und nicht nötig.

## Gruppe „Datenbank“

Dieser Button ist mit höchster Vorsicht zu benutzen! Denn hiermit wird der Inhalt der ***GESAMTEN Datenbank GELÖSCHT!*** Dieser Vorgang ist nach Bestätigung der Sicherheitsabfrage unwiderruflich!

Der Button ist inaktiv, wenn andere Fenster, also z.B. ein Timer-Panel, noch aktiv sind. Es müssen erst alle anderen Fenster geschlossen werden, bevor der Button aktiv wird.
