<link href="styles/styles.css" rel="stylesheet"></link>

# Timer-Panel Single-Table

Das Timer-Panel für den Single-Table stellt sich bei Erstaufruf z.B. wie folgt dar:

![Single mit Menü](img/single1.jpg)

Um Platz zu sparen, wird beim Single-Table auf die Anzeige der nächsten Blind-Stufe verzichtet. Wenn der Timer gestartet wurde, verkürzt sich das Fenster weiter:

![Single ohne Menü](img/single2.jpg)

## Menüzeile

Die Funktionalitäten der Menüzeile sind grundsätzlich die gleichen wie beim Main-Event Timer-Panel. Lediglich die Gruppe „Edit Prices“ fehlt, da ich davon ausgehe, dass diese in der Regel hier nicht gebraucht wird.

## Popup-Menü

### Single-Table alleine

Wenn der Single-Table alleine aktiv ist, also kein Main-Event parallel läuft, erscheint bei Drücken der rechten Maus-Taste abhängig von den jeweiligen Gegebenheiten eines der folgenden Popup-Menüs:

![Popup Single alone](img/popupsinglealone.png)

Die einzelnen Menü-Punkte sind weitgehend selbsterklärend bzw. wurden schon beim Timer-Panel des Main-Events erläutert:

* „Max Screen“: Das Fenster des Single-Tables hat eine feste Höhe, daher wird lediglich die Breite auf die maximal Breite des Monitors angepasst. Das Fenster wird am oberen Monitorrand ausgerichtet.
* „Min Screen“: Das Fenster wird lediglich in der Breite wieder auf die Mindestbereite des Fensters reduziert und horizontal zentriert. Höhe und Position bleiben ansonsten unverändert.

### Single-Table parallel zu Main-Event

Wenn ein Timer-Panel für ein Main-Event parallel zum Single-Table gestartet wird, werden die Anzeige-Optionen im Popup-Menü wie folgt ergänzt:

![Single paralle Main](img/popupsingleparallmain.png)

Die Auswahl „Max Both“ bzw. „Min Both“ führt dann zu den gleichen Ergebnissen wie beim Timer-Panel des Main-Events.
