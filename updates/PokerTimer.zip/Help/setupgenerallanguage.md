<link href="styles/styles.css" rel="stylesheet"></link>

# Dialog „Einstellungen“

![Dialog Einstellungen](img/setuplanguage.jpg)

Hier können generelle Einstellungen für das Programm gemacht werden. Der Aufruf ist auch mit „Alt“ (Windows) bzw. „Cmd“ (Mac) und Taste Komma (,) möglich.
Da die Timer-Panels nicht modal laufen, kann der Einstellungen-Dialog parallel aufgerufen werden. So ist es möglich, insbesondere die Farben anzupassen und das Ergebnis sofort im jeweiligen Timer-Panel zu sehen. Ebenso können dann gleich auch die Töne für Blind-Wechsel etc. geändert werden, ohne dass das Turnier bzw. der Single-Table unterbrochen werden muss.

## Gruppe „Allgemein - Sprache - Spracheinstellungen“

Im Programm können - als Spielerei - sämtliche Dialoge sowohl in Deutsch als auch in Englisch dargestellt werden. Einzig auf dem Timer-Panel bleiben die Anzeigen immer in Englisch. Hier werden lediglich die Mouse-over-Hilfetexte übersetzt.
Hingegen werden auch die „Auswertungen“, also insbesondere die Überschriften der Berichte, entsprechend übersetzt.

***Einschränkung***: Leider wird bei Umstellung von Deutsch auf Englisch in der Mac-Version eine Fehlermeldung „Access Violation“ angezeigt.

***Workaround***: Die Fehlermeldung kann einfach mit „OK“ bestätigt werden, das Programm arbeitet ansonsten dennoch fehlerfrei weiter.
