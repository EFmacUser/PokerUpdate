<link href="styles/styles.css" rel="stylesheet"></link>

# Dialog „Chips verwalten …“

![Chips verwalten](img/chipsmgm.jpg)

Die Funktionalitäten sind eigentlich selbsterklärend. Ergänzend kommt hinzu:

* Button „Bild“: Es wird ein Dialog zum Öffnen einer Grafik-Datei aufgerufen. Hierüber kann das Bild des aktuell ausgewählten Chips eingefügt bzw. ausgetauscht werden. Der Dialog wird auch durch Doppelklick auf das Bild aufgerufen.
* Button „Löschen“: Der selektierte Chip wird aus der Datenbank und damit in allen verwendeten Turnier-Sets gelöscht. Es erfolgt vorab eine Sicherheitsabfrage.

Bei der Auswahl bzw. der Erstellung des Bildes sollten folgende Punkte berücksichtigt werden:

* Es können grundsätzlich alle Grafik-Formate gewählt werden. JPEG und PNG sind in der Datenhaltung relativ genügsam.
* Zumindest bei PNG ist es möglich, das Bild des eigentlichen Chip freizustellen, so dass die „Ecken“ des Bildes keinen Hintergrund in der späteren Anzeige hinterlassen.
