<link href="styles/styles.css" rel="stylesheet"></link>

# „Chips“

![Chips](img/chips.jpg)

Der PokerTimer bietet die Möglichkeit, im Timer-Panel maximal sechs Bilder der Chips und ihrer Wertigkeit anzuzeigen. Die in der Datenbank vorhandenen Chips werden links in der Liste „Mögliche Chips“ dargestellt. Ganz neue Chip-Bilder müssen vorab über das Menü „Allgemein“->“Chips verwalten …“ in der Datenbank eingefügt werden. Danach können sie dann hier über die bekannten Funktionen Doppelklick und „Drag&Drop“ in die Liste „Gewählte Chips“ übernommen werden.
Aus der Liste „Gewählte Chips“ können Sie durch Doppelklick wieder gelöscht werden.
Durch Setzen des „Häkchens“ in der Spalte Anzeige in der Liste „Gewählte Chips“ wird festgelegt, welche Bilder beim Start im Timer-Panel angezeigt werden sollen:

![Chips](img/chips2.jpg)

Es werden die ersten sechs (sortiert nach Wertigkeit) mit „Häkchen“ angezeigt. Im Timer-Panel kann dies später aber wieder entsprechend angepasst werden.
