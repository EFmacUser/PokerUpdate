<link href="styles/styles.css" rel="stylesheet"></link>

# Dialog „Turniere löschen“

![Turnier löschen](img/gamesmgm.jpg)

Die Auswahl des zu löschenden Turniers erfolgt mit der Maus. Mit der Taste „STRG“ (Windows) bzw. „CMD“ (Mac) können auch mehrere Turniere ausgewählt und in einem Zug gelöscht werden.

***ACHTUNG:*** Wenn hier ein Turnier gelöscht wird, werden **ALLE** Daten des Turnier-Sets entfernt! Das beinhaltet sowohl die auf den weiteren Tabs erfassten Daten (Blinds, Spieler, Dealer, Punkte-Verteilung, Chips, Logo) als auch die während des Turniers gesammelten Werte, also insbesondere die Platzierungen der Spieler.

Es erfolgt zwar vorab eine Sicherheitsabfrage. Aber bei einer Löschung sollte immer Vorsicht walten!
