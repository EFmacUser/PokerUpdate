<link href="styles/styles.css" rel="stylesheet"></link>

# Blinds-Struktur

![Blindstruktur](img/blinds.jpg)

## Gruppe „Vorlagen“

### Button „Laden“

Über den folgenden Dialog kann die Blinds-Struktur eines beliebigen alten Turnier-Sets als Vorlage für das aktuell zu bearbeitende ausgewählt werden.

**Achtung:** Bei Auswahl der Blinds-Struktur wird eine ggf. bis dahin erstellte Struktur ohne Nachfrage gelöscht und durch diese ersetzt!

### Button „Vorlage“

Hiermit wird eine Standard-Blind-Struktur eingestellt. Diese ist oben im Bild enthalten. Sofern vorher eine Blind-Struktur vorhanden war, erfolgt vor dem Überschreiben eine Sicherheitsabfrage. Die Standard-Struktur kann anschließend noch frei verändert werden.

## Gruppe „Blind-Stufe“

### Button Blindstufe „Einfügen“

An der aktuellen Zeile wird eine neue leere Blindstufe zur Bearbeitung eingefügt. Dabei wird die Dauer der Blindstufe mit der Zeit der vorhergehenden Blind-Stufe vorbefüllt.

### Button Blindstufe „Löschen“

Die aktuell gewählte Blind-Stufe wird gelöscht. Ein Undo ist nicht möglich!

## Gruppe „Multi-Select“

Die Gruppe „Multi-Select“ wird erst aktiv, wenn in der Blind-Liste mindestens zwei Zeilen in der ersten Spalte selektiert wurden. Im Eingabe-Feld „Neue Blindzeit“ kann dann eine Zeit eingestellt werden, die bei Drücken des Buttons „Ändern“ sodann bei allen selektierten Zeilen übernommen wird.

![Blindstruktur](img/multiselect.jpg)

## Bearbeitung von Blindstufen

Die Felder können frei zur Bearbeitung ausgewählt werden. Alle Eingaben in einem Feld müssen mit „return“ abgeschlossen werden. Dies ist insbesondere in der Spalte „Dauer“ von Bedeutung, da bei Verlassen mit der Taste „Tabulator“ ansonsten die eingestellte Zeit nicht übernommen wird.

Nach Erfassung eines Small Blinds wird das Feld Big Blind automatisch mit dem doppelten Wert des Small Blinds vorbelegt.

Wird in der letzten Zeile in der Spalte „Ante“ die Eingabe mit „Return“ abgeschlossen, wird automatisch eine neue Blind-Stufe angehängt. Diese wird mit der Dauer der vorhergehenden Blind-Stufe vorbefüllt.

Ein „Return“ am Ende einer sonstigen Zeile erzeugt lediglich einen Sprung in die erste Spalte, in der selektiert werden kann, der folgenden Blindstufe.

Ist ein Feld in der Spalte „Level“ ausgewählt, kann die Blindstufe durch Drücken der Tasten „0“ bis „9“, „t“ bzw. „T“ (für „toggle“) oder „p“ bzw. „P“ (für „Pause“) in eine Pause oder wieder in eine Blindstufe geändert werden. Wurde Pause gewählt, werden die Felder für Blinds und Ante der Zeile gelöscht und können nicht mehr bearbeitet werden.

In der Spalte "Dauer" können mehrere Zeilen mit der Maus oder "Shift"+Pfeiltaste ausgewählt werden. Diese Zeilen werden dann in der ersten Spalte entsprechend aus- oder abgewählt. Durch Drücken des Spaltenkopfs der ersten Spalte, werden alle ausgewählten Zeilen wieder abgewählt.

Die Felder in den Spalten „Re-Buy“ und „Add-On“ können nur mit der Maus selektiert werden. Durch Auswahl ![Haken](img/Haken.jpg) wird gesteuert, ob in der Blind-Stufe noch ein Re-Buy und/oder Add-On möglich ist. Im Timer-Panel werden die zugehörigen Gruppen dann frei- bzw. abgeschaltet.
