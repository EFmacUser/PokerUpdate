<link href="styles/styles.css" rel="stylesheet"></link>

# Dialog „ Datenbank Dealer“

![Dealer bearbeiten](img/dealersall.jpg)

Die Funktionalitäten sind im Wesentlichen die gleichen wie oben unter Turniereinstellunge -> Tab Dealer dargestellt. Ergänzend kommt hinzu:

* Über den Button „Bearbeiten“ wird der ausgewählte Dealer zur Bearbeitung in die Felder „Vorname“, „Nachname“ und „E-Mail“ eingestellt. Nach erfolgter Anpassung wird der Button „Sichern“ aktiv und der geänderte Datensatz kann in der Datenbank gespeichert werden.
![Spieler bearbeiten](img/dealersall2.jpg)

* Über den Button „Löschen“ kann der / die selektierte/n Dealer aus der Datenbank gelöscht werden. Es erfolgt vorab eine Sicherheitsabfrage. Wird einer der selektierten Spieler jedoch noch in einem Turnier-Set verwendet, ist das Löschen nicht erlaubt und wird mit einem Hinweis bereits vor der Sicherheitsabfrage für alle selektierten Dealer abgebrochen.
