<link href="styles/styles.css" rel="stylesheet"></link>

# Dialog „Ausgabe von Turnier-Daten“

![Auswertungen](img/report.jpg)

Der Teilbereich Auswertungen stellt ein wesentliches Zusatz-Feature des PokerTimers dar. Insbesondere wenn mehrere Turniere einer Serie erfasst wurden, kann hierüber sehr einfach eine aktuelle Rangliste generiert werden.
Dabei wird grundsätzlich danach differenziert, ob man nur die Daten eines einzelnen, bestimmten Turniers ausgeben möchte (Gruppe „Turnier-Daten“) oder ob für eine ganze Serie von Turnieren (Gruppe „Rangliste“) die Daten kumuliert werden sollen, um daraus eine Rangliste zu erstellen.

## Button „Vorschau“

Über den Button wird sowohl im Bereich „Turnier-Daten“ als auch im Bereich „Rangliste“ in einem neuen Fenster eine Vorschau der jeweiligen Liste am Bildschirm angezeigt:

![Druckausgabe](img/report2.jpg)

Hierbei können über Buttons in der Menüzeile verschiedene Aktionen ausgelöst werden:

* Mit dem Button ![Drucken](img/report3.jpg) (Exit) oder durch drücken der Taste „ESC“ kann die Vorschau wieder verlassen werden.
* Der Button ![Speichern](img/report4.jpg) (Datei sichern als) bietet hingegen mehrere Optionen, die im Dialog aufgerufen werden können:
  * Der Bericht kann als Datei „meinName.FRP“ mit der automatisch vorgegebenen Endung „.FRP“ abgespeichert werden. Eigentlich nicht notwendig.
  * Wichtiger ist aber die Möglichkeit, den Bericht in den Formaten HTML und ASCII speichern zu können. Dazu muss das Format in der Combo-Box vorab ausgewählt werden: ![Auswahl](img/report5.jpg)
  * Insbesondere die ASCII-Datei kann ggf. als Import-Datei für einen Web-Publishing-Programm genutzt werden, um damit eine Web-Page mit der jeweiligen Rangliste zu generieren. In einer späteren Version kann der Output ggf. so weit optimiert werden, dass auch die HTML-Datei direkt weiterverarbeitet werden kann.
* Der Button ![Drucken](img/report6.jpg) (Drucken) ist insofern wichtig, da über ihn der System-Drucker-Dialog aufgerufen wird. Über diesen können vor dem Ausdruck in der Regel folgende Punkte eingestellt werden:
  * Welche Seiten sollen gedruckt werden?
  * Welcher Drucker soll verwendet werden? Da jedes System heute in der Regel auch einen pdf-Druckertreiber hat, ist es damit möglich, den Bericht auch als pdf abzulegen.
* Der Button ![Druckerauswahl](img/report7.jpg) (Druckerauswahl) erlaubt vorab die Auswahl eines Druckers. Dies kann besser im o.g. Drucken-Dialog gemacht werden. Die weiteren Einstellungsmöglichkeiten des Dialogs sollten grundsätzlich nicht genutzt bzw. verändert werden.
* Der Button ![Seiteneinrichtung](img/report8.jpg) (Seiteneinrichtung) bietet die üblichen Optionen zur Wahl der Papier-Ausrichtung sowie der Ränder.
* Die übrigen Buttons sollten selbsterklärend sein.

## Button „Druck“

Über den Button wird sowohl im Bereich „Turnier-Daten“ als auch im Bereich „Rangliste“ sofort eine Ausgabe auf dem aktuell im System als Standard hinterlegten Drucker erzeugt.

## Button „CSV“

Über den Button wird sowohl im Bereich „Turnier-Daten“ als auch im Bereich „Rangliste“ der ausgewählte Bericht „nackt“, also nur die reinen Zeilen mit den Daten, ohne Header-Zeile, ohne Seitenüberschrift oder -zahlen, im Unterverzeichnis "export" als CSV-Datei abgelegt. Dabei werden folgende Dateien geschrieben:

Dateiname | Inhalt
---------|----------
 CSVexpSingle.csv | Rangliste eines einzelnen Turniers
 CSVexpSeriesAll.csv | Rangliste aus allen Turnieren einer Serie
 CSVexpSeriesTopX.csv | Rangliste einer Serie, wobei nur die Top X Ergebnisse gewertet werden
 CSVexpSeries2Series.csv | Rangliste aus zwei Serien, wobei nur die Top X der einen sowie die Top Y Ergebnisse der anderen Serie gewertet werden

Die Spalten der Liste/Tabelle haben dabei folgenden Inhalt:
 1 | 2   | 3  
---------|----------|---------
 Platz | Nachname, Vorname | Punkte

Ein vorheriger Export der gleichen Art wird einfach überschrieben. Die Liste mit den Daten kann dann in weiteren Programmen wie Excel oder WordPress weiterverarbeitet werden.

## Gruppe „Turnier-Daten“

Über den Button „Öffnen“ wird mit dem bekannten Öffnen-Dialog ein einzelnes Turnier-Set ausgewählt. Dieses ist die Basis für die mit diesem Teilbereich möglichen Auswertungen, welche über die Combo-Box „Berichtsart“ ausgewählt werden:

![Berichtsart](img/report9.jpg)

### „Liste der gemeldeten Teilnehmer“

Eine Sonderliste, die am Bildschirm so aussieht:

![Gemeldete Teilnehmer](img/report10.jpg)

Sofern bereits im Vorfeld Zahlungen in Bargeld oder Wertmarken im Dialog erfasst wurden, werden diese im Ausdruck mit angezeigt.
Über die Erfassung im Feld „Cap Spieler“ ![Cap](img/report11.jpg) kann gesteuert werden, wieviele Leerzeilen im Bericht angedruckt werden sollen. Wenn bislang lediglich 20 Spieler angemeldet sind, werden so nach den 20 Spielern noch 28 Leerzeilen angedruckt. Ein Beispiel für einen Ausdruck mit Leerzeilen ist oben zu sehen.
Dadurch können die Meldungen auch noch vor Ort papierhaft erfasst werden. Besser ist es natürlich, alle Spieler und ihre Zahlungen direkt im Tab „Spieler“ zu erfassen.

### „Platzierungen des Turniers“

Hiermit kann eine Ergebnisliste nach Abschluss eines einzelnen Turniers ausgegeben werden. Es werden die Namen der Spieler, ihr Platz und die erzielten Punkte (sofern eine entsprechende Struktur über den Tab „Punkte-Verteilung“ erfasst wurde), aufgegliedert nach Punkte (aufgrund Platzierung), Bonus-Punkte und Gesamt-Punkte, ausgegeben. Das Ergebnis sieht am Bildschirm so aus:

![Platzierungen](img/report12.jpg)

### „Abrechnung der Kasse des Turniers“

Hier werden am Ende des Turniers alle Bargeldzahlungen und Wertmarken aufsummiert und als Saldo dargestellt. Bargeld-Einnahmen summieren sich dabei von allen Spielern, wohingegen der „Lohn“ für die festen Dealer als Bargeld-Ausgabe betrachtet und summiert wird.
Bei den Wertmarken werden hingegen alle erhaltenen und dann alle als „Wechselgeld“ ausgegebenen Wertmarken je Nominale aufsummiert. Daher sollte hier am Ende bei den Spielern, die als „Gewinn“ Wertmarken erhalten, dies als Ausgabe beim jeweiligen Spieler erfasst werden.
Das Ergebnis sieht dann am Bildschirm z.B. so aus:

![Kasse](img/report13.jpg)

## Gruppe „Rangliste“

Hierüber kann die Rangliste einer Turnier-Serie bzw. mehrerer Serien ausgegeben werden. Es werden die Ergebnisse aller Spieler aller Turniere, die über den Filter „Turnier-Serie“ zusammengehören, aufaddiert und entsprechend ausgegeben.

Dabei kann zwischen folgenden Arten ausgewählt werden:

![Berichtsart](img/report14.jpg)

### „Alle Ergebnisse einbeziehen“

Alle Turnier-Ergebnisse der Serie eines Spieler werden addiert, um die Ranglisten-Punkte zu ermitteln.

### „Nur Top X-Ergebnisse einbeziehen“

Hier werden nur die X besten Turnier-Ergebnisse des Spielers in der Serie berücksichtigt und aufaddiert, um die Ranglisten-Punkte zu ermitteln.

Die Anzahl der besten zu wertenden Turnier-Ergebnisse kann
frei zwischen 1 und 99 festgelegt werden.

Das Ergebnis sieht bei beiden Varianten am Bildschirm wie folgt aus:

![Bericht Top x](img/report15.jpg)

### „Top X und Y—Ergebnisse von zwei Serien addieren“

Hier werden die X besten Ergebnisse eines Spielers einer Turnier-Serie (Main-Event) und die Y besten Ergebnisse einer weiteren Turnier-Serie (Single-Table) berücksichtigt und aufaddiert, um die Ranglisten-Punkte zu ermitteln.

Die Anzahl der besten zu wertenden Turnier-Ergebnisse ist frei zwischen 1 und 99 einstellbar. Voreingestellt sind fünf und drei.

Das Ergebnis unterscheidet sich nur durch den geänderten Kopf des Berichts und sieht dann am Bildschirm wie folgt aus:

![Bericht Top x und y](img/report16.jpg)

## Gruppe „Nachnamen anpassen“

![Anpassung Nachnamen](img/report17.jpg)

Hier wird festgelegt, ob der Nachname des Spielers in der Auswertung voll ausgeschrieben wird oder aber nur die ersten x Buchstaben gefolgt von einem „Punkt“, z.B. „Bet.“ anstatt „Bethke“, angezeigt werden. Die hier gewählte Einstellung wirkt auf alle Auswertungen, also sowohl bei den beiden Einzel-Turnier-Auswertungen (Ergebnis- bzw. Spielerliste) als auch bei den drei Turnier-Serien-Auswertungen (Alle Ergebnisse, Top X und Top X und Y aus 2 Serien). Die Anzahl der anzuzeigenden Buchstaben kann im Dialog "Einstellungen", Tab "Allgemein", Unter-Tab "Beschriftung" festgelegt werden.

Alle oben beispielhaft eingefügten Listen wurden mit der Option „gekürzter Nachname“ erstellt. Als Standard ist „vollständiger Nachname“ eingestellt.
