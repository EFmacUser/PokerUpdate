<link href="styles/styles.css" rel="stylesheet"></link>

# Dialog „Einstellungen“

![Dialog Einstellungen](img/setupdatabase.jpg)

Hier können generelle Einstellungen für das Programm gemacht werden. Der Aufruf ist auch mit „Alt“ (Windows) bzw. „Cmd“ (Mac) und Taste Komma (,) möglich.
Da die Timer-Panels nicht modal laufen, kann der Einstellungen-Dialog parallel aufgerufen werden. So ist es möglich, insbesondere die Farben anzupassen und das Ergebnis sofort im jeweiligen Timer-Panel zu sehen. Ebenso können dann gleich auch die Töne für Blind-Wechsel etc. geändert werden, ohne dass das Turnier bzw. der Single-Table unterbrochen werden muss.

## Gruppe „Allgemein - Datenbank - Datenbank“

Dieser Button ist mit höchster Vorsicht zu benutzen! Denn hiermit wird der Inhalt der ***GESAMTEN Datenbank GELÖSCHT!*** Dieser Vorgang ist nach Bestätigung der Sicherheitsabfrage unwiderruflich!

Der Button ist inaktiv, wenn andere Fenster, also z.B. ein Timer-Panel, noch aktiv sind. Es müssen erst alle anderen Fenster geschlossen werden, bevor der Button aktiv wird.
