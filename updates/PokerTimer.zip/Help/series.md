<link href="styles/styles.css" rel="stylesheet"></link>

# Dialog „Turnier-Serien bearbeiten …“

![Turnier-Serien bearbeiten](img/series.jpg)

Die hier hinterlegten Filter können bei der Erstellung eines Turnier-Sets diesem zugeorndet werden. Auf diese Weise kann eine Rangliste verschiedener Turniere, die den gleichen Serien-Filter haben, erstellt werden.

Die Funktionalitäten der Buttons sind selbsterklärend.

Ergänzend kann hier aber auch der Text eines bestehenden Filters angepasst werden, so dass er bei allen verwendeten Turnieren entsprechend geändert wird.

***Achtung:*** Sollte ein Filter gelöscht werden, so wird er auch in allen verwendeten Turnier-Sets gelöscht. Im jeweiligen Turnier-Set wird dann ein leeres Feld angezeigt. Daher ist bei der Löschung von Turnier-Filtern Vorsicht angeraten!
