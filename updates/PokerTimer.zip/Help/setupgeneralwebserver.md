<link href="styles/styles.css" rel="stylesheet"></link>

# Dialog „Einstellungen“

![Dialog Einstellungen](img/setupwebserver.jpg)

Hier können generelle Einstellungen für das Programm gemacht werden. Der Aufruf ist auch mit „Alt“ (Windows) bzw. „Cmd“ (Mac) und Taste Komma (,) möglich.
Da die Timer-Panels nicht modal laufen, kann der Einstellungen-Dialog parallel aufgerufen werden. So ist es möglich, insbesondere die Farben anzupassen und das Ergebnis sofort im jeweiligen Timer-Panel zu sehen. Ebenso können dann gleich auch die Töne für Blind-Wechsel etc. geändert werden, ohne dass das Turnier bzw. der Single-Table unterbrochen werden muss.

## Gruppe „Allgemein - Web-Server - Web-Server“

Der im PokerTimer integrierte Web-Server ist standardmäßig darauf eingestellt, über den Port 8888 Befehle entgegen zu nehmen. Sollte dieser Port von einem anderen Programm benutzt werden, kann der Port hier beliebig geändert werden.
Damit der Web-Server über den neuen Port erreichbar ist, muss der PokerTimer nach einer Änderung aber erst neu gestartet werden.
Die IP-Adresse des Rechners, auf dem der PokerTimer und damit auch der Web-Server laufen, wird vom Programm automatisch beim Programmstart ermittelt. Das manuelle Anstoßen der Suche über den Button „Update“ sollte nur in Ausnahmefällen nötig sein. Eine manuelle Erfassung hingegen ist nicht möglich und nicht nötig.
