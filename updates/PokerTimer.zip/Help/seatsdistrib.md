<link href="styles/styles.css" rel="stylesheet"></link>

# Dialog „Sitzverteilung"

Der Dialog „Sitzverteilung“ kann erst geöffnet werden, wenn auch Spieler vorhanden sind. Es kann dann die Sitzplatz-Verteilung angepasst werden:

![Dialog Sitzverteilung](img/sitzverteilung.jpg)

Für jeden „festen Dealer“, diese sind am dunkelgrauen Hintergrund zu erkennen, und „spielenden Dealer“, erkennbar am beigen Hintergrund, wird automatisch ein Tisch eröffnet, dem sie als Dealer zugeordnet werden.
Die Spieler werden zunächst nach der Reihenfolge ihrer Erfassung den Plätzen am Tisch zugeordnet. Ist ein Tisch voll, wird automatisch ein neuer Tisch aufgemacht, auch wenn es noch keinen Dealer für den Tisch gibt.
Per „Drag&Drop“ können Spieler auf freie Plätze „umgesetzt“ werden. Auf diese Weise kann ein „spielender Dealer“ auch wieder zum „normalen“ Spieler werden oder ein Spieler auf einen freien Dealer-Platz gesetzt werden und so zum „spielenden Dealer“ werden.
Feste Dealer können nicht auf einen Spielerplatz sondern lediglich auf einen freien Dealer-Platz umgesetzt werden.

## Gruppe Zufallsverteilung

Anstatt manuell die Spieler und Dealer umzuverteilen, kann dies auch per Zufallsfunktion über den Button „Mix“ geschehen. Dabei werden pro Tisch soviel Plätze erstellt, wie gemäß Erfassungsvorgabe „Plätze pro Tisch“ vorgesehen sind. Die Spieler werden gleichmäßig über alle vorhandenen Tische verteilt.
Standardmäßig werden die Dealer bei jeder Zufallsverteilung neu den Tischen zugeordnet. Bei einem größeren Turnier mit bereits festgelegten Zuordnungen Tisch-Dealer ist dies nicht sinnvoll. Daher kann über Deselektion des Hakens bei "Dealer auch mixen" die Verteilung der Dealer unterbunden werden.

## Gruppe „Plätze pro Tisch“

Möchte man nun lieber eine kleinere Anzahl von Plätzen pro Tisch haben, kann dies durch Anpassung im Feld ![Feld](img/feld.jpg) und Drücken des Buttons „Ändern“ angepasst werden. Im folgenden Beispiel wurde die Sitzplatzzahl auf „9“ reduziert:

![Anpassung Sitze](img/sitzverteilung2.jpg)

Dadurch wird nicht nur die Anzahl der Plätze angepasst, sondern die Verteilung der Spieler ändert sich dementsprechend, da im Beispiel "Max10 Tester" ja nicht mehr auf Platz 10 an Tisch 1 sitzen kann, da es diesen nicht mehr gibt. Bei einem laufenden Turnier mit "zwischendrin" freien Plätzen an den Tischen (wie im obigen Beispiel) kommt es hierbei immer zu Tisch-übergreifenden Verschiebungen von Spielern. Dies ist bei Änderung der Platzanzahl zu berücksichtigen!  
Natürlich kann jetzt erneut eine manuelle oder Zufallsverteilung der Spieler und Dealer vorgenommen werden.
Werden nach Erstellung der Sitzverteilung in den Tabs „Spieler“ und „Dealer“ neue Teilnehmer erfasst oder ggf. gelöscht, wirkt sich das natürlich auf die Sitzverteilung entsprechend aus.
Neue Spieler werden einfach auf den ersten freien Platz beginnend bei Tisch 1 gesetzt.
Ein neuer Dealer kommt auf den ersten freien Dealer-Platz oder - wenn keiner vorhanden ist - wird für ihn ein neuer Tisch aufgemacht.
Daher ist die Sitzverteilung ggf. noch einmal zu überprüfen, wenn man Veränderungen bei den Teilnehmern vornimmt.

## Gruppe „Leeren Tisch löschen“

Wenn durch das manuelle Umgruppieren von Spielern und Dealern ein Tisch ***gänzlich*** leer ist, kann er hierüber gelöscht werden. Im unten beigefügten Beispiel somit der Tisch 2.

![Leerer Tisch](img/empttable.jpg)

## Gruppe „Schriftgröße“

Um die Anzeige für Dritte, also insbesondere bei Anzeige über einen Beamer, lesbarer zu machen, kann die Schriftgröße für die Spieler-/Dealer-Namen angepasst werden. Die Spaltengrößen passen sich entsprechend an. Insbesondere macht es dann auch Sinn, den Dialog über den „Maximieren“-Knopf im System-Menü des Dialogs auf die gesamte Bildschirmgröße zu maximieren.

## Gruppe „Nachnamen anpassen“

Hierüber kann gesteuert werden, ob der Nachname vollständig oder lediglich gekürzt angezeigt werden soll. Die Anzahl der anzuzeigenden Buchstaben, wird zentral im Dialog "Einstellungen" für alle Programmteile festgelegt. Bei den Beispielbildern wurde die Kürzung auf zwei Buchstaben eingestellt.

## Gruppe „Auswahl Bildschirm“

Sofern am System mehrere Monitore angeschlossen sind, kann hiermit der Monitor für die Ausgabe gewählt werden. Da sofort auf den neuen Monitor, also z.B. einen Beamer, mit dem die Anzeige für alle öffentlich wird, geswitcht wird, sollten die sonstigen Einstellungen vorab eingestellt sein.
Über den Button „Update“ kann die Liste der verfügbaren Monitore aktualisiert werden, um Monitore zu ergänzen, die erst nach dem Start des Dialogs Platzverteilung angeschlossen worden sind.

## Popup-Menü

Mit der rechten Maustaste kann hier ein Popup-Menü mit lediglich einem Auswahlfeld aufgerufen werden:

![Popup](img/popup2.jpg)

Hiermit kann das vollständige Menü des Dialogs ausgeblendet werden. Dies ist sinnvoll, wenn die endgültige Verteilung steht und Dritten angezeigt wird. Dann sollte der Dialog auch maximiert werden, siehe Gruppe „Schriftgröße“.
