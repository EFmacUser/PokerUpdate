<link href="styles/styles.css" rel="stylesheet"></link>

# Dialog „Einstellungen“

![Dialog Einstellungen](img/setupsounds.jpg)

Hier können generelle Einstellungen für das Programm gemacht werden. Der Aufruf ist auch mit „Alt“ (Windows) bzw. „Cmd“ (Mac) und Taste Komma (,) möglich.
Da die Timer-Panels nicht modal laufen, kann der Einstellungen-Dialog parallel aufgerufen werden. So ist es möglich, insbesondere die Farben anzupassen und das Ergebnis sofort im jeweiligen Timer-Panel zu sehen. Ebenso können dann gleich auch die Töne für Blind-Wechsel etc. geändert werden, ohne dass das Turnier bzw. der Single-Table unterbrochen werden muss.

## Gruppe „Timer-Panel - Töne - Hinweis-Töne“

Bislang sind die auswählbaren Sounds zwar übersichtlich, aber diese können nun frei den drei Ereignissen zugeordnet werden:

* Blind: Bei jeder Änderung der Blind-Stufe wird dieser Sound abgespielt.
* Minute: Mit diesem Sound wird die letzte Minute der Blind-Stufe angekündigt.
* Sekunde: Dieser Sound wird jeweils bei den letzten fünf Sekunden der Blind-Stufe abgespielt.

Über den Button „Reset“ werden die Standard-Töne für das jeweilige Timer-Panel wiederhergestellt. Die vorherigen Einstellungen gehen dabei verloren, auch wenn man den Dialog über Button „Abbruch“ verlässt.
