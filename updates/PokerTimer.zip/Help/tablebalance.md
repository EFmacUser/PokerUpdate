<link href="styles/styles.css" rel="stylesheet"></link>

# Dialog „Spieler umsetzen“

![Dialog Spieler umsetzen](img/tablebalance.jpg)

* Hier kann über die gleiche Funktionalität wie beim Dialog „Sitz-Verteilung“->“Anzeige“ per Drag&Drop eine manuelle Umverteilung der Spieler und Dealer vorgenommen werden.
* Alle aktuellen Umsetzungen werden im Bereich „Umsetzungen“ in der Liste protokolliert, so dass sie entsprechend an die Spieler kommuniziert werden können. Sobald der Dialog geschlossen wird, wird die Liste jedoch gelöscht. Dann muss die aktuelle Tisch-Sitz-Nr. eines Spielers über die Liste im Dialog „Spieler ausgeschieden“ herausgesucht werden.
* Über die Gruppe „Tisch auflösen“-> Button „Auflösen“ wird der gewählte Tisch vom Programm aufgelöst und die Spieler auf die verbliebenen Tische per Zufall verteilt. Sofern nicht genügend Plätze an den verbliebenen Tischen frei sind, gibt es einen Hinweis.
* Sofern das Turnier mit einer geringeren Sitz-Zahl je Tisch gestartet wurde, weil z.B. an jedem Tisch nur acht Spieler sitzen sollten, kann über „Plätze pro Tisch“-> Button ![Plätze erhöhen](img/plus.jpg) nun die Zahl der Sitze je Tisch erhöht werden. Maximal werden 13 Plätze plus Dealer zugelassen.Umgekehrt kann über den Button ![Plätze verringern](img/minus.jpg) die Anzahl der Sitze an allen verbliebenen Tischen reduziert werden. Sofern dieser Sitz nicht an allen Tischen frei ist, gibt es einen Hinweis. In diesem Fall müsste der betreffende Spieler ggf. vorher umgesetzt werden.
