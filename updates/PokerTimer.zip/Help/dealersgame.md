<link href="styles/styles.css" rel="stylesheet"></link>

# „Dealer“

![Dealer hinzufügen](img/dealersgame.jpg)

Die Funktionalitäten und das Handling sind grundsätzlich die gleichen wie auf dem Tab „Spieler“.

Die Reihenfolge der Spalten in der Liste „Mögliche Dealer“ kann per Drag&Drop verändert werden. Ebenso kann durch Klicken des Spaltenkopfs die Liste nach der jeweiligen Spalte auf- oder absteigend sortiert werden.

Die Reihenfolge der Spalten der Liste „Gewählte Dealer“ kann nicht geändert werden. Das Sortieren wird ebenfalls durch Klicken der Spaltenköpfe gesteuert.

Wichtig ist lediglich zu wissen, dass das Programm zwischen „festen Dealern“ und „spielenden Dealern“ unterscheidet. Auf diesem Tab werden ausschließlich „feste Dealer“ erfasst.

Da die festen Dealer in der Regel eine Vergütung für ihre Arbeit erhalten, kann man hier das je Dealer gezahlte Entgelt erfassen. Dies wird dann in der Auswertung „Abrechnung der Kasse des Turniers" berücksichtigt.

Einen Spieler macht man hingegen auf dem folgenden Tab „Sitz-Verteilung“ zum spielenden Dealer. Nur spielende Dealer werden später während des Turniers im Dialog „Spieler ausgeschieden“ angezeigt, um sie als nicht mehr aktive Spieler kennzeichnen zu können.
