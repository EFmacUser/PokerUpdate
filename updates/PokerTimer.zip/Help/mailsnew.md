<link href="styles/styles.css" rel="stylesheet"></link>

# Tab "Anmeldungen - Offen"

![Neue Mails](img/mailsnew.jpg)

Vom hinterlegten Mail-Server werden die Anmeldungen für das Turnier heruntergeladen und können dann entsprechend weiterverarbeitet werden. Ziel ist es, jeder Mail-Anmeldung letztlich einen Spieler aus der Spieler-Datenbank des PokerTimers zuzuordnen oder ihn aus anderen Gründen abzulehnen, so dass die Liste "Geladene Mails" leer ist. Danach erfolgt die weitere Bearbeitung auf dem nächsten Unter-Tab "Bearbeitet", sprich es werden Antwort-Mails versendet.

## Gruppe „Geladene Mails“

Die vom Server heruntergeladenen Turnieranmeldungen werden aufgelistet.
Durch Klick auf die Spaltenköpfe kann entsprechend auf- oder absteigend sortiert werden.

### Button „Laden“

In den Einstellungen werden die relevanten Account-Daten für den Mail-Server hinterlegt. Dort wird ausgewählt, ob der Server seitens des Pokertimers per POP3 oder IMAP verwaltet werden soll.

Es werden nur Mails heruntergeladenen, die in der Betreffzeile den korrekten Wert aufweisen. Diese Betreff-Zeile muss immer einheitlich sein und wird von der Homepage des Turnierbetreibers in der E-Mail aus dem Kontaktformular gesetzt. Der relevante Vergleichswert für die Betreff-Zeile wird ebenfalls in den Einstellungen hinterlegt.

### Check-Feld „Mails löschen“

Dieses Check-Feld wird nur angezeigt, wenn in den Einstellungen für den zu nutzenden Posteingang-Server IMAP vorgegeben wurde. Dort wird auch die Vorbelegung gesetzt, die hier im Tab aber temporär / situationsbedingt wieder geändert werden kann.
Ist der Haken gesetzt, werden die heruntergeladenen E-Mails auf dem IMAP-Server gelöscht. Sie können dann dort nicht mehr mit einem anderen E-Mail-Client, z.B. auf dem Handy, bearbeitet werden.

Bei IMAP ist der Standard eher, dass die E-Mails nicht gelöscht werden. Bei einem POP3-Server werden die E-Mails nach dem Download **immer** auf dem Server gelöscht. Dies kann im PokerTimer nicht beeinflusst werden.

## Bearbeitungsbuttons

Mit den folgenden Buttons wird die jeweilige selektierte Mails direkt auf den Unter-Tab "Bearbeitet" verschoben, wo dann ggf. weitere Bearbeitungsschritte, insbesondere der Versand von Antwort-Mails, erfolgen. In Abhängigkeit von dem genutzten Button erhält die Mail einen spezifischen Status.

### Button „Irrelevant“

Mit dieser Option können Mails als bearbeitet gekennzeichnet werden, bei denen mit dem relevanten Betreff versehentlich ein anderer Mail-Inhalt gesendet wurde. In diesem Fall ist der eigentliche Mail-Inhalt dann verloren, da er nicht ausgelesen wird. Sofern über IMAP ohne Option "Mails löschen" geladen wurde, kann die Mail noch auf dem Server bearbeitet werden.
Des Weiteren kann diese Option genutzt werden, um (erneute) Anmeldungen von Spielern, die bereits vorher als Teilnehmer dem Turnier zugeordnet wurden, als "Bearbeitet" zu markieren. 
Der Status der Mail im Unter-Tab "Bearbeitet" lautet "NR", also nicht relevant.

### Button „Voll“

Wenn noch Anmeldungen kommen, aber die maximale Kapazität des Turniers schon erreicht ist, wird die Anmeldung auf den Unter-Tab "Bearbeitet" verschoben und mit dem Status "Abg.", also abgelehnt versehen.

### Button „Turnier“

Die Anmeldung betrifft ein anderes Turnier, z.B. das des vorhergehenden Monats. Die Mail kann dann diesem Turnier zugeordnet werden. Alternativ wäre auch die Markierung über "Irrelevant" möglich.

## Gruppe „Suchergebnisse“

![Suchergebnisse](img/mailsnew2.jpg)

Immer wenn in der Liste "Geladene Mails" eine Mail selektiert wird, wird nach entsprechenden Treffern in der Spieler-Datenbank gesucht. Dabei sind die Suchfelder Vorname, Name und E-Mail-Adresse jeweils mit einer Oder-Bedingung verknüpft. Damit soll verhindert werden, dass Schreibfehler, z.B. im Feld Vorname, zu einem negativen Suchergebnis führen, denn dann würde der Spieler dennoch aufgeführt werden, weil entweder der Name und/oder die E-Mail-Adresse noch treffen. Auch kann dies relevant werden, wenn sich zwei Spieler, z.B. Eheleute, anmelden, die die gleiche E-Mail-Adresse benutzen. Groß-/Kleinschreibung wird bei der Suche nicht beachtet.

Spieler in der Suchliste, die bereits im Turnier angemeldet sind, werden gelb hinterlegt.

Ist in der Liste Suchergebnisse ein Spieler selektiert, werden die Buttons "Auswahl" und "Bearbeiten" aktiv geschaltet.

### Button „Auswahl“

Wird ein noch nicht angemeldeter Spieler ausgewählt, wird er über den Button "Auswahl" zum einen auf den Unter-Tab "Bearbeitet" mit dem Status "Reg.", also registriert = angemeldet, verschoben. Zum anderen wird er auch automatisch in die Liste der Spieler im Tab "Spieler" eingefügt.

Wird in der Trefferliste ein Spieler, der bereits dem Turnier zugeordnet wurde, also gelb hinterlegt ist, ausgewählt, so wird der Button "Auswahl" zu "Erledigen". Der Spieler kann dann dennoch auf den Unter-Tab "Bearbeitet" verschoben werden, erhält aber auf dem Unter-Tab den Status als ob der Button "Irrelevant" gedrückt worden wäre, also "NR".

### Button „Bearbeiten“

Für den ausgewählten Spieler wird der Ändern-Dialog aufgerufen. Hier kann man die Felder Vorname, Name und E-Mail bearbeiten. Dies macht z.B. Sinn, wenn für den Spieler bislang nur der Vorname bekannt war, er nun aber mit der Anmeldung auch seinen Nachnamen mitgeliefert hat.

### Button „Neu“

Der Button wird bereits aktiv geschaltet, sobald eine Mail in der Liste "Geladene Mails" ausgewählt wird. Sollte der Teilnehmer aus der Mail-Anmeldung noch nicht in der Spieler-Datenbank vorhanden sein, kann er über den Button entsprechend in der Datenbank eingefügt werden. Anschließend steht er in der Liste der Suchergebnisse zur Auswahl zur Verfügung.
