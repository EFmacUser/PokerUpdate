<link href="styles/styles.css" rel="stylesheet"></link>

# Dialog „Einstellungen“

![Dialog Einstellungen](img/setupmail.jpg)

Hier können generelle Einstellungen für das Programm gemacht werden. Der Aufruf ist auch mit „Alt“ (Windows) bzw. „Cmd“ (Mac) und Taste Komma (,) möglich.
Da die Timer-Panels nicht modal laufen, kann der Einstellungen-Dialog parallel aufgerufen werden. So ist es möglich, insbesondere die Farben anzupassen und das Ergebnis sofort im jeweiligen Timer-Panel zu sehen. Ebenso können dann gleich auch die Töne für Blind-Wechsel etc. geändert werden, ohne dass das Turnier bzw. der Single-Table unterbrochen werden muss.

## Tab „Allgemein - Mail-Account“

Üblicherweise hat der Turnierbetreiber eine Homepage, auf der mittels eines Kontaktformulars eine Anmeldung zum nächsten Turnier erfolgen kann. Die Homepage sendet dann eine E-Mail an den Turnierleiter mit den relevanten Anmelde-Daten. Dies dürften in der Regel der Vorname, Name und die E-Mail-Adresse des Spielers sein, die in entsprechenden Feldern im Kontaktformular abgefragt wurden. Unterstellt wird, dass die E-Mail der Homepage immer einen einheitlichen "Betreff" hat und dass die übergebenen Daten eine vorgegebene Struktur aufweisen.

## Gruppe „Allgemein - Mail-Account - Login“

Hier werden die Login-Daten für den Mail-Server hinterlegt, bei dem die Anmeldungen von der Homepage des Turnierbetreibers gespeichert werden. Benutzer ist meist die E-Mail-Adresse, z.B. <max.muster@gmx.net>, und das zugehörige Passwort.

## Gruppe „Allgemein - Mail-Account - Posteingang“

Über diese Daten kann der Maileingangs-Server des Anbieters erreicht werden. Hier kann nach POP3 und IMAP differenziert werden. Da alle Server i.d.R. nur noch verschlüsselte Verbindungen akzeptieren, versucht der PokerTimer eine entsprechende Verbindung herzustellen. Dazu ist es wichtig, dass der Port erfasst wird, auf dem der Server verschlüsselte Verbindungen erwartet. Die entsprechenden Zugangsdaten des Servers können leicht durch eine Google-Suche ermittelt werden.
Bei einem POP3-Server werden die heruntergeladenen Mails anschließend auf dem Server gelöscht. Bei IMAP-Servern ist der Standard, dass die Mails nach dem Download auf dem Server verbleiben, damit andere E-Mail-Clients, z.B. auf dem Handy, diese noch bearbeiten können. Sollen diese jedoch gelöscht werden, kann dafür das Check-Feld „Mails löschen" gesetzt werden. Im eigentlichen Download-Dialog im Tab „Anmeldungen - Offen" kann dies temporär übersteuert werden.

## Gruppe „Allgemein - Mail-Account - Postausgang“

Hier müssen entsprechend die Daten für den Mailausgangs-Server des Anbieters erfasst werden. Die Verbindung wird per verschlüsseltem SMTP aufgebaut. Daher muss auch hier der Port hinterlegt werden, auf dem der Server verschlüsselte Verbindungen erwartet. Die entsprechenden Zugangsdaten des Servers können ebenfalls durch eine Google-Suche ermittelt werden.
Des Weiteren können hier die Absender-Angaben hinterlegt werden. Zum einen der Klarname des Turnierleiters oder ein sonstiges Synonym, z.B. „Friesland-Open". Zum anderen die E-Mail-Adresse, an die geantwortet wird, wenn der Empfänger auf "Antworten" in seinem E-Mail-Client drückt.

## Gruppe „Allgemein - Mail-Account - Mail-Struktur"

Mittels der hier hinterlegten Informationen ist der PokerTimer in der Lage, die relevanten Daten aus den Mails zu extrahieren und dann weiter zu verarbeiten.  
Im Feld "Betreff" ist die genaue Betreffzeile zu erfassen, die die Homepage verwendet. Es werden nur Mails vom Server abgerufen, die genau diese Betreff-Zeile haben. 

Die Daten für Vorname, Nachname und E-Mail werden im Nachrichten-Teil der Mail übermittelt. Dabei wird davon ausgegangen, dass es jeweils ein spezielles Schlüsselwort pro Datenfeld gibt. Also dass z.B. erst das Schlüsselwort "Vorname:" und danach der tatsächliche Vorname (= das Datum), also z.B. "Dag", in der Mail steht. Diese drei Schlüsselwörter sind in der Tabelle entsprechend zu erfassen. Auch hier ist es wichtig, sie genau so zu erfassen, wie sie von der Homepage verwandt werden. Im vorigen Beispiel würde das Schlüsselwort "Vorname", also ohne Doppelpunkt, zu Fehlern führen.

Die Anordnung von Schlüsselwort und zugehörigem Datum kann auf zwei unterschiedliche Arten vorliegen. Entweder in einer einzeiligen oder einer zweizeiligen Version:
Bei der einzeiligen Version sind die Daten in der gleichen Zeile wie das Schlüsselwort selbst gespeichert, also z.B.

"Vorname: Dag".

Bei der zweizeiligen Version steht das Schlüsselwort in einer und das Datum in der nächsten Zeile, also z.B.  

"Vorname:"  
"Dag"
