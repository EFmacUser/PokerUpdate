<link href="styles/styles.css" rel="stylesheet"></link>

# „Punkte / Gewinn“

![Punkte-Dialog](img/points.jpg)

Die Funktionalitäten sind für die Buttons „Laden“, „Einfügen“ und „Löschen“ selbsterklärend bzw. entsprechen denen des Tabs „Blinds-Struktur“.
Der Dialog kann auch noch im Timer-Panel in der Gruppe „Edit Prices“ bzw. „Edit Points“ während des laufenden Turniers aufgerufen werden.
Es gibt immer mindestens so viele Zeilen/Plätze wie im Tab „Spieler“ auch Spieler für das Turnier aufgenommen wurden. Neben der freien Hinterlegung einer Punkte-Struktur ist auch die freie Belegung einer prozentualen Gewinn-Struktur möglich.
Die Daten können frei in den Spalten „Punkte“ bzw. „Gewinn %“ erfasst werden. Lediglich bei der Spalte „Gewinn %“ achtet das Programm darauf, dass in einem Feld kein Wert größer 100,00 erfasst wird. Zudem werden alle erfassten Werte dieser Spalte aufaddiert und unten als „Summe“ angezeigt. Damit kann man sofort erkennen, wenn man „zu viel“ verteilt hat.

## Vorbelegung: Gruppe „Punkte“

Im folgenden Beispiel sollen lediglich die drei Erstplatzierten Punkte für eine imaginäre Rangliste erhalten:

![Punkte-Dialog](img/points2.jpg)

Im Verlaufe des Turniers wird aber für jeden ausgeschiedenen Spieler festgehalten, auf welchem Platz er das Turnier beendet hat. Dadurch kann man im Nachgang für ein Turnier ggf. noch die Punktverteilung für die Plätze anpassen. Dies wird dann automatisch den Spielern zugeordnet.
Es können hier über die beiden Buttons zwei Vorbelegungen „OO“ (Ostfriesland Open) und „PLN“ (PokerLigaNord) genutzt werden.
Mit dem Button „Reset“ wird die Spalte „Punkte“ komplett gelöscht.

### Button „OO“

Die „OO“ nutzt eine Spieler- bzw. Tisch-abhängige Belegung der Punktverteilung. Auch wenn das bei diesen Turnieren nicht vorkommt, würden bei der Anzahl Spieler auch Re-Buys als Spieler gewertet werden.
Durch „Mouse-Over“ beim jeweiligen Button wird ein Erläuterungstext für die Standard-Belegung angezeigt. Das obige Bild zeigt diesen Text für die Ostfriesland Open.

### Button „PLN“

Die „PLN“ nutzt eine Spieler-unabhängige also fixe Belegung der Punktverteilung. Auch wenn das bei diesen Turnieren nicht vorkommt, würden bei der Anzahl Spieler auch Re-Buys als Spieler gewertet werden.
Durch „Mouse-Over“ beim jeweiligen Button wird ein Erläuterungstext für die Standard-Belegung angezeigt. Das folgende Bild zeigt den Text für die PokerLigaNord:

![Punkte](img/points3.jpg)

## Vorbelegung: Gruppe „Gewinn %“

Die Gewinn-Verteilung kann zum einen durch Erfassung entsprechender Prozentwerte frei erfasst werden oder man nutzt die Buttons, um auf Standard-Vorbelegungen zurückzugreifen.
Mit dem Button „Reset“ wird die Spalte „Gewinn %“ komplett gelöscht.

### Button „S+G“

Bei einem „Sit and Go“-Turnier (S+G) wird abhängig von der Zahl der angemeldeten Spieler folgende Struktur hinterlegt:
1 bis 4 Spieler   = 100 % für den Ersten
5 bis 7 Spieler   = 70 - 30 %
8 bis 10 Spieler  = 50 - 30 - 20 %
11 bis 20 Spieler = 50 - 25 - 15 - 10 %
über 21 Spieler   = 40 - 25 - 20 - 10 - 5 %
Dabei wird auf die aktuell hinterlegten Spieler abgestellt. Hierbei werden Spieler, die sich durch ein Re-Buy erneut in das Turnier einkaufen, als neue Spieler im Sinne der teilnehmenden Spieler gewertet. Sollten nach Hinterlegung der Gewinnverteilung noch neue Spieler hinzugefügt werden oder Re-Buys erfolgen, muss die Gewinnverteilung noch einmal neu hinterlegt werden.
Durch „Mouse-Over“ beim Button „S + G“ wird ein Erläuterungstext für die Standard-Belegung angezeigt:

![Punkte](img/points4.jpg)

### Button „MTT“

Bei normalen Multi-Table-Turnieren (MTT) erhalten etwa 10 %  der Spieler Geld, während 90 % der Spieler leer ausgehen. Der Großteil des Geldes wird aber erst am Final Table, also an die Spieler, die den letzten Tisch erreichen,  vergeben.
Typisch ist eine Preisgeld-Verteilung von 25 % für die  Spieler, die vor dem Final Table ausscheiden, und 75 % des  Preisgeldes für die Spieler, die den Final Table erreichen.  Davon gehen etwa 25 % an die Plätze zehn bis vier, während  die Hälfte des Preisgeldes an die letzten drei Spieler geht.
Daraus ergibt sich folgende feste Gewinnverteilung für die  ersten 10 Plätze, mit der 75 % des Gesamtpotts verteilt werden:

Platz | Prozent
:----:|:------:
  1   |  18,75
  2   |  11,25
  3   |  7,50
  4   |  6,00
  5   |  6,00
  6   |  6,00
  7   |  6,00
  8   |  4,50
  9   |  4,50
  10  |  4,50

Die restlichen 25 % des Gesamtpotts werden auf die restlichen 10 % der Spieler abzüglich der ersten 10 Plätze zu gleichen Anteilen verteilt.  Sollten aufgrund von Rundungen nicht genau 100 % verteilt werden, werden zu wenig verteilte Prozentsätze dem 1. Platz zugeschlagen und ggf. zu viel verteilte Werte beim letzten bezahlten Platz abgezogen.
Es wird auf die aktuell hinterlegten Spieler abgestellt. Hierbei werden Spieler, die sich durch ein Re-Buy erneut in das Turnier einkaufen, als neue Spieler im Sinne der teilnehmenden Spieler gewertet. Sollten nach Hinterlegung der Gewinnverteilung noch neue Spieler hinzugefügt werden oder Re-Buys erfolgen, muss die Gewinnverteilung noch einmal neu hinterlegt werden.
Da eine Gewinnverteilung für 10 % der Spieler erst bei einem Teilnehmerfeld größer 200 Spielern Sinn macht, ist dieser Button vorher entsprechend abgeschaltet.

### Button „DoN“

Bei einem „Double or Nothing“ (DoN), manchmal auch „Double Up“ genannt, gewinnt die Hälfte der Spieler den doppelten Betrag des geleisteten Einsatzes, während die  andere Hälfte leer ausgeht.
Insbesondere bei einer ungeraden Zahl von Spielern kann es zu einem "Rest" kommen, der dann dem 1. Platz zugewiesen wird.
Es wird auf die aktuell hinterlegten Spieler abgestellt. Sollten nach Hinterlegung der Gewinnverteilung noch neue Spieler hinzugefügt werden, muss die Gewinnverteilung noch einmal neu hinterlegt werden.
