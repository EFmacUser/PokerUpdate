<link href="styles/styles.css" rel="stylesheet"></link>

# Dialog „Liste der Turnier-Spieler“

In der Liste „Mögliche Spieler“ werden alle in der Datenbank bislang vorhandenen Spieler aufgelistet, die nicht bereits in die rechte Liste „Gewählte Spieler“ des aktuellen Pokerspiels aufgenommen wurden. Sobald also ein Spieler in die rechte Liste „Gewählte Spieler“ übernommen wird, steht dieser in der Liste „Mögliche Spieler“ nicht mehr zur Verfügung.  Doppelerfassungen werden dadurch ausgeschlossen.

Die Reihenfolge der Spalten in der Liste „Mögliche Spieler“ kann per Drag&Drop verändert werden. 

Die Reihenfolge der Spalten der Liste „Gewählte Spieler“ kann nur über das Popup-Menü (siehe unten) geändert werden. 

Durch Klicken eines Spaltenkopfs in einer der Listen kann nach der jeweiligen Spalte auf- oder absteigend sortiert werden. In der Liste „Gewählte Spieler“ kann auch nach der Spalte „Bar“ sortiert werden. Dadurch werden alle Spieler, die noch nicht bezahlt haben, als erstes angezeigt bzw. umgekehrt.

## Anlegen neuer Spieler

![Spieler hinzufügen](img/playersplus.jpg)

Um einen neuen Spieler anlegen zu können, muss nach ihm zunächst in der Datenbank gesucht werden. Dazu können die Felder „Vorname“, Nachname“ und/ oder „E-Mail“ mit den (Teil-) Suchbegriffen gefüllt werden. Mit dem Button „Reset“ werden nach einer Suche die Felder wieder gelöscht, damit wieder alle Datensätze angezeigt werden.

Durch die Vorab-Suche soll verhindert werden, dass Spieler doppelt angelegt werden bzw. nicht erkannt wird, dass ein Spieler gleichen Namens existiert, aber keine Personenidentität besteht. Dann sollte der neue Spieler eine Ergänzung, z.B. im Vornamen, erhalten, um ihn später differenzieren zu können. Mit dem Button „Einfügen“ werden die gemachten Eingaben in den Feldern dann als neuer Datensatz in die Datenbank geschrieben.

## Übernahme von Spielern

Ein Spieler kann per „Drag&Drop“ in die Liste „Gewählte Spieler“ gezogen werden. Dabei können vorher mittels Taste „STRG“ (Windows) bzw. „CMD“ (Mac) auch mehrere Spieler ausgewählt worden sein. Ebenso werden ein oder mehrere selektierte Spieler in die Liste „Gewählte Spieler“ übernommen, wenn der Button „Auswahl“ gedrückt wird.

Ein einzelner Spieler kann alternativ auch per Doppel-Klick ausgewählt werden. Er wird dann sogleich in die „Liste der gewählten Spieler“ übernommen.

Sofern ein Spieler übernommen wurde, kann dann die Höhe und Art seines bezahlten Buy-Ins erfasst werden. Das Programm unterscheidet zwischen Zahlung mit Bargeld und / oder mit Wertmarken („Coins“). Dies kann in den Spalten entsprechend erfasst werden:

![Wertmarken anzeigen](img/coins.jpg)

Es können sowohl erhaltene als auch als „Wechselgeld“ wieder ausgegebene Wertmarken hinterlegt werden. Zudem sollte am Ende des Turniers bei den Spielern, die als „Gewinn“ Wertmarken erhalten haben, dies als ausgegebene Wertmarken jeweils erfasst werden. Dies ist für die Gesamtabrechnung, die auch als Ausdruck im Bereich „Auswertungen“ bezogen werden kann, wichtig.

## Löschen von Spielern

Wurde ein Spieler versehentlich in die „Liste der gewählten Spieler“ aufgenommen, wird er durch Doppel-Klick in die Spalte Vorname oder Name aus der Liste gelöscht und steht in der Liste  „Mögliche Spieler“ wieder zur Auswahl zur Verfügung. Vor der Löschung erfolgt eine Sicherheitsabfrage.

## Popup-Menü

Durch Drücken der rechten Maus-Taste in der „Liste der gewählten Spieler“ erscheint folgendes Popup-Menü:

![Popup](img/popup.jpg)

Damit kann für das aktuelle Turnier-Set und die erfassten Spieler eine Teilnehmer-Liste angesehen oder direkt gedruckt werden. Die Funktionalitäten sind dann grundsätzlich die gleichen wie bei Aufruf über Menü „Allgemein“->“Auswertungen“, siehe entsprechend dort. Lediglich die Anzahl der möglichen Spieler für die Liste, also entsprechende Leer-Zeilen, kann hier im Tab „Spieler“ nicht eingestellt werden. Sie ist fest mit 48 vorgegeben.

Des Weiteren kann hier die Reihenfolge der Spalten Vorname - Nachname geändert werden.

Ebenso ist es möglich, die Nachnamen gekürzt oder vollständig anzeigen zu lassen.
