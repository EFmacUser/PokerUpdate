<link href="styles/styles.css" rel="stylesheet"></link>

# Dialog „Einstellungen“

![Dialog Einstellungen](img/setupmonitors.jpg)

Hier können generelle Einstellungen für das Programm gemacht werden. Der Aufruf ist auch mit „Alt“ (Windows) bzw. „Cmd“ (Mac) und Taste Komma (,) möglich.
Da die Timer-Panels nicht modal laufen, kann der Einstellungen-Dialog parallel aufgerufen werden. So ist es möglich, insbesondere die Farben anzupassen und das Ergebnis sofort im jeweiligen Timer-Panel zu sehen. Ebenso können dann gleich auch die Töne für Blind-Wechsel etc. geändert werden, ohne dass das Turnier bzw. der Single-Table unterbrochen werden muss.

## Gruppe „Timer-Panel - Bildschirm - Auswahl Bildschirm“

Sofern am System mehr als ein Monitor angeschlossen ist, kann hiermit standardmäßig vorgegeben, auf welchem Monitor beim Start die Timer-Panels angezeigt werden sollen. In der Regel bietet sich hier die Auswahl eines Beamers an.
Über den Button „Update“ kann die Liste der verfügbaren Monitore aktualisiert werden, um Monitore zu ergänzen, die erst nach dem Start des Einstellungen-Dialogs angeschlossen worden sind.
Wenn das jeweilige Timer-Panel gestartet wurde, kann das Fenster aber auch manuell auf einen der vorhandenen Monitore gezogen werden. Das Timer-Panel merkt sich den Monitor für den nächsten Start. Sollte dann nur noch ein Monitor vorhanden sein (z.B. Beamer wurde noch nicht angeschlossen) wird standardmäßig wieder auf dem Primär-Monitor ausgegeben.
