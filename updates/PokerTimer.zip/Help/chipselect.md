<link href="styles/styles.css" rel="stylesheet"></link>

# Dialog "Chip-Anzeige anpassen"

 ![Popup-Menü](img/chipsanzeige.jpg)

 Mit dem Dialog „Chip-Anzeige anpassen“ können die Chip-Bilder ausgewählt werden, die noch bzw. neu angezeigt werden sollen, da kleine Chip-Werte aus dem Turnier herausgenommen wurden und ggf. größere Chip-Werte eingeführt wurden.
