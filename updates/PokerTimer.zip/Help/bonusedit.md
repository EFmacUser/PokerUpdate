<link href="styles/styles.css" rel="stylesheet"></link>

# Dialog "Erfassung der Bonus-Punkte"

![Bonus-Punkte](img/bonuspoints.jpg)

Mit dem Dialog „Erfassung der Bonus-Punkte“ ist es möglich, den Spielern noch eine freie Anzahl von Bonus-Punkten zuzuordnen, die z.B. als Bounties erzielt wurden.

Diese werden sowohl beim jeweiligen Einzel-Turnier den Punkten, die aufgrund der Platzierung erzielt werden, als auch bei Auswertung einer Gesamtrangliste berücksichtigt, siehe Menü „Allgemein-> Auswertungen“.
