<link href="styles/styles.css" rel="stylesheet"></link>

# Timer-Panel Main-Event

Das Timer-Panel ist sozusagen die zentrale Funktionalität, mit der ein Pokerspiel letztlich abläuft.
Bei Erstaufruf stellt sich der Timer des Main-Events z.B. wie folgt dar:

![Timer-Panel Main-Event](img/timer.jpg)

Im Beispiel—Turnier wurden sowohl Bilder der Chips als auch ein Logo geladen.  Dazu ist auch noch die Preis-Struktur eingeblendet.
Zudem ist die Menü-Zeile, mit der der Ablauf des Spiels gesteuert und die Ergebnisse dokumentiert werden, sichtbar. Im Folgenden werden daher zunächst die wesentlichen Buttons der Menü-Zeile erläutert.

## Menüzeile

Solange das Turnier noch nicht gestartet wurde, ist die Menüzeile sichtbar. Mit Beginn des Turniers wird diese automatisch ausgeblendet. Sie wird erst wieder eingeblendet, wenn die laufende Blind-Phase pausiert wurde (über die „Leer“-Taste oder Taste „P“). Ansonsten muss das Menü dann über das Popup-Menü, siehe Kapitel 12.2, wieder eingeblendet werden.

### Gruppe „Players“

![Gruppe Players](img/timer2.jpg)

* Button ![Seat Open](img/playerminus.jpg) (Seat Open) ruft den Dialog „Spieler ausgeschieden“ zur Dokumentation der ausgeschiedenen Spieler auf. Der Aufruf ist alternativ auch über die Taste „-“ möglich.

* Button ![Neuer Spieler](img/playerplus.jpg) (neuer Spieler) ruft den Dialog „Liste der Turnier-Spieler“ auf. Aufruf ist alternativ auch über die Taste „+“ möglich. Hier können während des laufenden Turniers neu hinzugekommene Spieler erfasst werden. Sie erhalten entsprechend einen Platz, der dann aber nur über die Liste im  Dialog „Spieler ausgeschieden“ abgefragt werden kann. Dies sollte wohl die Ausnahme sein.

## Gruppe „Re-Buy“

![Rebuy](img/timer3.jpg)

* Mit dem Button ![Plus](img/plus.jpg)  kann vermerkt werden, dass ein vorhandener Spieler sich erneut eingekauft hat. Dies ist für die Preisverteilung und die Anzahl der durchschnittlichen und Gesamt-Chips von Interesse. Die Anzahl der aktiven Spieler wird dadurch nicht erhöht, aber ein Re-Buy wird intern bei der Berechnung der Preisstruktur wie ein neuer Spieler gewertet. Dazu muss ggf. über die Gruppe „Edit Prices“ die Struktur aktualisiert werden.Sollte man versehentlich oder zu oft auf  gedrückt haben, kann dies mit dem Button ![Minus](img/minus.jpg) wieder rückgängig gemacht werden. Die Gesamtanzahl der Re-Buys wird rechts in der Gruppe angezeigt.
* Die Gruppe ist nur aktiv, wenn dies in der Blind-Liste für die aktuelle Stufe entsprechend festgelegt wurde.

## Gruppe „Add-On“

![Add-On](img/timer4.jpg)

* Gleiche Funktionalität wie Gruppe „Re-Buy“ zur Dokumentation der erfolgten Add-Ons.
* Die Gruppe ist nur aktiv, wenn dies in der Blind-Liste für die aktuelle Stufe entsprechend festgelegt wurde.

## Gruppe „Edit Prices“

![Prices](img/timer5.jpg)

Sofern im Turnier um ein Preisgeld gespielt wird und dies in den Turnier-Einstellungen entsprechend ausgewählt wurde, kann hier eingestellt werden, wie die Berechnung der einzelnen Preisstufen erfolgen soll. Die Anzeige im Bereich „Price-Pool“ wird entsprechend angepasst:

![Preispool](img/timer6.jpg)

* Auswahl „Exact“: Die Beträge werden mit Cent-Beträgen genau berechnet und dargestellt.
* Auswahl „Rounded“: Die einzelnen Preisgeld-Stufen werden jeweils auf volle 5 € aufgerundet. Ein evtl. verbleibender Rest-Cent-Betrag wird der letzten Preisgeld-Stufe zugeschlagen.
* Über den Button ![Edit Prices](img/timer7.jpg) wird der Dialog zur Bearbeitung der Punkte- und Gewinn-Struktur aufgerufen, der bereits oben im Tab „Punkte / Gewinn“ vorgestellt wurde. Während des Turniers ist das wichtig, da die Gewinn-Struktur i.d.R. von der Anzahl der Spieler abhängig ist, welche sich während des laufenden Turniers durch neue oder fiktive (durch Re-Buys) Spieler erhöht haben kann. Dann kann die Struktur hier aktualisiert werden.
* In der Preisstruktur werden nur Plätze angezeigt, die einen Gewinn erhalten. Plätze mit „0,00“ Euro werden ausgeblendet.

## Gruppe „Edit Points“

![Points](img/timer8.jpg)

Wurde in den Turnier-Einstellungen hingegen die Anzeige der Punkte-Struktur gewählt, verändert sich die Anzeige entsprechend:

![Punkte-Struktur](img/timer9.jpg)

* Die Auswahl für die Art der Preisdarstellung entfällt.
* Über den Button ![Edit Points](img/timer7.jpg) wird wie oben der Dialog zur Bearbeitung der Punkte-Struktur angezeigt. Dies ist insbesondere erforderlich, wenn durch zahlreiche Re-Buys sich die „fiktive“ Gesamtanzahl der Spieler so weit erhöht hat, dass eine gewählte Spieler-abhängige Punktstruktur aktualisiert werden muss.
* In der Punktestruktur werden nur Plätze angezeigt, die auch Punkte erhalten. Plätze mit „0“ Punkten werden ausgeblendet.
* Bei der Anzeige der Struktur wird zudem nicht die Gesamtsumme des Preispools angezeigt, sondern die Anzahl der Plätze, die Punkte erhalten. Im Beispiel ist also der 13. Platz der „bubble boy“.

## Gruppe „Blind-Levels“

![Blind-Struktur](img/timer10.jpg)

Hierüber erfolgt die Steuerung der aktuellen Blind-Stufe. Über die beiden Buttons ![Skip Left](img/skipl.jpg) und ![Skip Right](img/skipr.jpg) kann entsprechend eine Blind-Stufe zurück oder vor gesprungen werden.
Alternativ kann auch Taste „Pfeil links“ oder „Pfeil rechts“ gedrückt werden.
Über den Button ![Edit Blinds](img/timer7.jpg) kann der im Kapitel ‚Tab „Blinds-Struktur“‘ beschriebene Dialog zur Bearbeitung der Blinds-Struktur während des Turniers aufgerufen und die Struktur komplett bearbeitet werden.

## Gruppe „Adjust Blind-Time“

![Adjust Blind-Timer](img/timer12.jpg)

Hiermit kann die abgelaufene Zeit der aktuellen Blind-Stufe manipuliert werden.

* Verschieben des Schiebereglers
* Drücken des Button ![Manuelle Blind-Time](img/timer13.jpg): Der Timer für die Blind-Stufe wird angehalten und es erscheint anstatt des Schiebereglers ein Eingabefeld für die Uhrzeit. Damit kann die abgelaufene Zeit sekundengenau erfasst werden. Wichtig ist wiederum, dass die Eingabe mit der Taste „return“ abgeschlossen wird, damit die neue Zeit übernommen wird und wieder der Schieberegler angezeigt wird.Maximal kann die Dauer der Blindzeit der aktuellen Blindstufe gem. Blinds-Struktur eingestellt werden. Soll die Länge der Blindstufe über die ursprünglich vorgegebene maximale Dauer hinaus verlängert werden, muss die Blinds-Struktur über den Button ![Edit Time](img/timer7.jpg) bearbeitet werden.

## Popup-Menü

### Main-Event alleine

![Popup-Menü](img/popupmainalone.png)

Wenn das Main-Event alleine aktiv ist, also parallel kein Single-Table läuft, erscheint bei Drücken der rechten Maus-Taste abhängig von den jeweiligen Gegebenheiten eines der folgenden Popup-Menüs:
Die einzelnen Menü-Punkte sind weitgehend selbsterklärend:

* „Start Game“ bzw. „Stop Game“: Sobald das Turnier gestartet wird, wechselt die Anzeige in „Stop Game“. Hintergrund ist, dass bei Turnier-Start die Menü-Zeile ausgeblendet wird. Dann kann hierüber das Turnier wieder gestoppt werden.Alternativ kann das Turnier auch immer über die „Leertaste“ oder Taste „p“ gestartet und gestoppt werden.
* „Seat Open“: Aufruf des Dialogs „Spieler ausgeschieden“. Dies geht schneller als wenn man erst die Menü-Zeile wieder einblendet und dann dort den Button ![Popup-Menü](img/playerminus.jpg) drückt.
Alternativ kann der Dialog auch mit der Taste „-“ aufgerufen werden.
* „Hide Menu“ bzw. „Show Menu“: Ein- bzw. Ausblenden der Menü-Zeile.
* „Edit Chips“: Damit wird der Dialog „Chip-Anzeige anpassen“ aufgerufen, so dass die Chip-Bilder ausgewählt werden können, die noch bzw. neu angezeigt werden sollen, da kleine Chip-Werte aus dem Turnier herausgenommen wurden und ggf. größere Chip-Werte eingeführt wurden.

* „Hide Prices“ bzw. „Show Prices“: Hiermit wird gesteuert, ob der Bereich „Price-Pool“ und die Gruppe „Price-Style“ angezeigt werden soll. Sofern in den Turnier-Einstellungen die Anzeige der Punkte-Struktur gewählt wurde, wird im Popup-Menü entsprechende „Hide Points“ bzw. „Show Points“ angezeigt.
* „Full Screen“ bzw. „Normal Screen“: Maximieren der Anzeige auf die gesamte Bildschirmgröße. Dabei werden alle Menüs, auch das Start-Menü von Windows, ausgeblendet. Entsprechend kann wieder auf die vorherige Größe des Timer-Panel-Fenster zurückgeschaltet werden. Das Fenster kann auch manuell in der Größe verändert werden.

### Main-Event parallel zu Single-Table

Wenn ein Timer-Panel für ein Single-Table parallel zum Main-Event gestartet wird, ist eine Fullscreen-Darstellung des Main-Events nicht mehr möglich. Beide Timer-Panels müssen parallel auf dem Bildschirm dargestellt. Daher ändern sich die Anzeige-Optionen im Popup-Menü:

![Popup Tablebalance](img/popupbalance.png)

* „Edit Chips“ ist inaktiv, da die Chip-Anzeige abgeschaltet ist.
* Mit „Max Both“ werden Anpassungen der horizontalen und vertikalen Größe vorgenommen. Das Fenster für das Single-Event ist in der Höhe fix, daher erfolgt nur horizontale Vergrößerung auf die maximale Breite des Monitors. Dabei wird das Single-Table-Fenster unten am Monitorrand angeordnet. Das Fenster des Main-Events schließt darüber an und nimmt die restliche maximale Höhe und Breite des Monitors ein.
* Bei „Min Both“ werden beide Fenster lediglich in der Breite wieder auf das kleinste Maß eingeschrumpft. Die Höhen bleiben bestehen, also über die gesamte Monitorhöhe.
