<link href="styles/styles.css" rel="stylesheet"></link>

# „Sitz-Verteilung“

![Tab Sitzverteilung](img/sitzverteilungframe.jpg)

Mit diesem Dialog kann die gesamte Sitzplatz-Verteilung für ein Pokerspiel organisiert werden.
In den Listen „Spieler“ und „Feste Dealer“ werden die in den vorherigen Tabs gewählten Teilnehmer aufgelistet.

## „Spielender Dealer“

Per Doppelklick, den Button ![Pfeil rechts](img/pfeilr.jpg) oder per „Drag&Drop“ kann ein Spieler aus der Liste „Spieler“ in die Liste „Spielende Dealer“ verschoben werden.
Ein „spielender Dealer“ wird wieder zum „normalen“ Spieler durch Doppelklick, den Button ![Pfeil rechts](img/pfeill.jpg)  oder per „Drag&Drop“.

## Button „Anzeige“

Der Button „Anzeige“ wird erst aktiv, wenn auch Spieler vorhanden sind. Es kann dann der Dialog zur Anpassung der Sitzplatz-Verteilung geöffnet werden.

## Nachnamen anpassen

Auswahl, ob der Nachname gekürzt oder vollständig angezeigt werden soll. Dies bezieht sich auf alle drei Listen.

## Sortierung

Auswahl, ob nach Nachname oder Vorname sortiert werden soll. Dies bezieht sich auf alle drei Listen.
