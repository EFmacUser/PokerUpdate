<link href="styles/styles.css" rel="stylesheet"></link>

# Dialog „Einstellungen“

![Dialog Einstellungen](img/setupgeneralupdate.jpg)

Hier können generelle Einstellungen für das Programm gemacht werden. Der Aufruf ist auch mit „Alt“ (Windows) bzw. „Cmd“ (Mac) und Taste Komma (,) möglich.
Da die Timer-Panels nicht modal laufen, kann der Einstellungen-Dialog parallel aufgerufen werden. So ist es möglich, insbesondere die Farben anzupassen und das Ergebnis sofort im jeweiligen Timer-Panel zu sehen. Ebenso können dann gleich auch die Töne für Blind-Wechsel etc. geändert werden, ohne dass das Turnier bzw. der Single-Table unterbrochen werden muss.

## Gruppe „Allgemein - Aktualisierung“

Ab der Version 1.6.0.0 kann der PokerTimer über das Internet auf einen GitHub-Server zugreifen, der immer die aktuellste Version zur Verfügung stellt. Ob eine neuere Version existiert, wird automatisch bei jedem Programmstart geprüft, sofern eine Internet-Verbindung besteht.
Ggf. meldet sich hier eine installierte Firewall und lässt sich den Zugriff bestätigen. Auch kann es sein, dass sich nun ein ggf. installierter Virenscanner meldet. Hintergrund ist, dass der GitHub-Server über eine HTTPS-Verbindung, also eine verschlüsselte Kommunikation, angesprochen wird. Wenn die dafür notwendigen DLL-Dateien nicht auf dem System installiert sind, werden diese vom PokerTimer aus dem Internet geladen und im Programmverzeichnis abgelegt. Da es sich hierbei im weitesten Sinne um System-Dateien handelt, kann das den Virenscanner auf den Plan rufen, so dass der Zugriff bitte erlaubt werden muss.

Sofern ein Update vorliegt und noch nicht installiert wurde, werden die Neuerungen der Version im Memo-Feld angezeigt.

## Gruppe „Allgemein - Aktualisierung - Download“

Es kann bereits bei Programmstart entschieden werden, ob der Download der neuen Version im Hintergrund gestartet werden soll. Der Fortschritt des Downloads wird in der Statuszeile des Hauptprogrammfensters angezeigt.

Grundsätzlich wird man bereits beim Programmstart den Download eines verfügbaren Updates auslösen, da er im Hintergrund abläuft und das Programm währenddessen normal weiter genutzt werden kann. Sollte der Download dort nicht gestartet worden sein, kann dies mit dem Button "Download" hier nachgeholt werden. Der Button ist nur aktiv, wenn eine neuere Version im GitHub vorliegt und diese nicht bereits geladen wurde.

## Gruppe „Allgemein - Aktualisierung - Update“

Über den Button "Update" wird erst die eigentliche Installation des heruntergeladenen Upates vom Nutzer aktiv ausgelöst. Der Button ist nur aktiv, wenn auch ein bereits heruntergeladenes Update zur Verfügung steht und keine Timer-Panels aktiv sind.
Für die Installation wird ein Hilfsprogramm (updater.exe) gestartet, das dann die Kopieraktionen ausführt, dabei meldet sich - je nach Einstellung - ein ggf. installierter Virenscanner. Auch hier sollte der Zugriff entsprechend erlaubt werden, da sonst das Update scheitert.
