<link href="styles/styles.css" rel="stylesheet"></link>

# Tab "Anmeldungen - Bearbeitet"

![Neue Mails](img/mailsedited.jpg)

Auf diesem Unter-Tab können die Mails versendet werden, um die eingegangenen Mails zu beantworten. In der Regel dürften dies positive Antworten sein, dass die Teilnahme am Turnier bestätigt wird. Genauso können aber natürlich auch Absagen erteilt werden.
Dazu werden erst die entsprechenden Mail-Empfänger und dann die zugehörige Mail-Nachricht mit Betreff ausgewählt und dann gesendet.

## Gruppe „Bearbeitete Mails“

### Listeninhalt

In der Liste werden alle auf dem Unter-Tab "Offen" bearbeiteten Mails mit ihrem Status in der jeweiligen Spalte aufgeführt. Ein zutreffender Status wird jeweils mit einem ![Haken](img/haken.jpg) in der Spalte versehen:

Spalte | Bedeutung |
---------|----------|
 Reg. | Registriert = im Turnier angemeldet |
 Abg. | Abgelehnt = nicht angemeldet |
 AW: | Mail wurde beantwortet |
 NR | nicht relevant |

Der Status "AW:" kann nicht manuell gesetzt werden, sondern erfolgt automatisch sobald eine Mail an diesen Empfänger gesendet wurde.

Durch Klick auf die jeweilige Kopfspalte wird die Liste auf- bzw. absteigend sortiert.

### Drop-Down-Liste „Mails auswählen“

Grundsätzlich können die Mails, die beantwortet werden sollen, manuell mit der Maus unter üblicher Nutzung der Tasten [SHIFT] und [STRG] bei Windows bzw. [CMD] bei Mac selektiert werden.
Das Programm bietet hier aber eine Unterstützung für zwei spezifische Situationen:

![Mails selektieren](img/DDMailSelection.jpg)

1. "Bestätigung Teilnahme": Selektion aller Mails von Teilnehmern, die im Turnier angemeldet wurden, aber noch keine Mail-Bestätigung erhalten haben.
2. "Absage Teilnahme": Selektion der Mails, die eine Absage erhalten sollen, da das Turnier bereits voll war.
3. "Keine": Dient lediglich dazu, alle Selektionen - auch manuelle - wieder aufzuheben.


## Gruppe „Mail-Versand“

Hier wird der Text für die zu versendende Mail erstellt. Im ersten Textfeld wird die Betreffzeile erfasst. Hier sind keine Formatierungen möglich, da das auch von keinem Mailprogramm unterstützt wird.

Das zweite große Textfeld ist ein rudimentärer Texteditor, bei dem die grundlegenden Formatierungen **fett**, *kursiv* und <u>unterstrichen</u> genutzt werden können. Daneben ist es möglich, unterschiedliche Schriftarten, -farben und -größen über einen Dialog einzustellen. Der so erstellte RTF-Text wird vor dem Versand als HTML-Text-Nachricht in den Mail-Body eingefügt.

### Drop-Down-Liste „Text-Vorlage wählen“

Insgesamt können hier pro Turnier drei Textvorlagen erstellt und abgespeichert werden. Diese haben folgende Namen:

![Textvorlagen selektieren](img/DDTextSelection.jpg)

1. "Sonstiges": Diese kann für freie Texte genutzt werden.
2. "Zusage": Hier sollte der Antwort-Text gespeichert werden, den angemeldete Turnier-Teilnehmer erhalten. Diese Vorlage dürfte am häufigsten zum Einsatz kommen, weshalb sie vorausgewählt ist.
3. "Absage": Dementsprechend die Text-Konserve für Teilnehmer, die nicht mehr aufgenommen werden konnten.

### Button „Senden“

Der Button ist erst aktiv, wenn mindestens ein Mail-Empfänger in der Gruppe "Bearbeitete Mails" ausgewählt wurde. Für alle ausgewählten Mail-Empfänger wird bei Drücken eine Mail mit der gerade aktiven Textvorlage versendet. Sind mehrere Mail-Empfänger ausgewählt, wird dennoch keine Sammel-Mail erstellt, damit die Empfänger nicht die Mail-Adressen der anderen Teilnehmer sehen können.
