<link href="styles/styles.css" rel="stylesheet"></link>

# Turnier auswählen

![Turnierset öffnen](img/opengames.jpg)

Mit dem Dialog „Turnier auswählen“ kann ein bereits im Vorfeld erstelltes / bearbeitetes Turnier-Set geladen werden.  

Durch Doppel-Klick kann ein Turnier-Set direkt ausgewählt werden. Um gezielt ein Turnier-Set zu suchen, kann nach Datum, Turniername und/oder Serie in der Gruppe „Suche“ gesucht werden:

* Es reicht Teilbegriffe einzugeben, dabei wird nicht nach Groß-/Kleinschreibung unterschieden.

* Das Datum kann entweder manuell im Format JJJJ-MM-TT, also vierstellige Jahreszahl, zweistellige Monate bzw. Tage, getrennt durch einen Gedankenstrich „-“, oder über den aufrufbaren Kalender ausgewählt werden. Bei manueller Erfassung kann z.B. auch lediglich „2023“ erfasst werden, um alle Turniere des Jahres zu erhalten. Damit das Datum übernommen wird, muss mit Taste „Return“ abgeschlossen werden.

Die drei Suchfelder sind mit einem logischen „UND“ verknüpft.  

Über den Button „Reset“ werden die Suchfelder gelöscht und wieder alle vorhandenen Turniere angezeigt.
