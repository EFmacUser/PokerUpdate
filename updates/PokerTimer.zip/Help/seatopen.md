<link href="styles/styles.css" rel="stylesheet"></link>

# Dialog „Spieler ausgeschieden“

![Spieler ausgeschieden](img/seatopen.jpg)

Der Dialog „Spieler ausgeschieden“ dient zur Dokumentation der ausgeschiedenen Spieler:

* Der selektierte Spieler wird durch Doppelklick oder den Button „Raus“ in der Gruppe „2. Auswahl“ als ausgeschieden markiert und der Platz vermerkt, den er erreicht hat. Alternativ kann in der Gruppe „1. Eingabe“ durch Eingabe von Tisch-Nr. und Sitz-Nr. der ausgeschiedene Spieler identifiziert werden und dort mit dem Button „Raus“ entsprechend markiert werden.
* Über den Button „Undo“ in der Gruppe „2. Auswahl“ wird der jeweils letzte ausgeschiedene Spieler auf seinen alten Platz gesetzt. Wurde zwischenzeitlich der Dialog „Tisch-Ausgleich“ aufgerufen, bekommt der Spieler nicht seinen alten Platz, sondern den nächsten freien zugewiesen. In diesem Fall müsste er manuell über den Dialog „Spieler umsetzen“ umgesetzt werden (mehr siehe dort).
* Der Button „Balance“ in der Gruppe „Tisch-Ausgleich“ ruft den Dialog „Spieler umsetzen“ auf, der auch eine automatische Tisch-Auflösung beinhaltet. Siehe hierzu das gesonderte Kapitel ‚Dialog „Spieler umsetzen“‘.
* Button „Bearbeiten“ in der Gruppe „Bonus-Punkte“ öffnet den Dialog „Erfassung der Bonus-Punkte“, um den Spielern noch eine freie Anzahl von Bonus-Punkten zuordnen zu können, die z.B. als Bounties erzielt wurden.
