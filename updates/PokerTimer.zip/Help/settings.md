<link href="styles/styles.css" rel="stylesheet"></link>

# Turnier-Daten

![Turnierdaten](img/settings.jpg)

Hier kann das gesamte Pokerspiel konfiguriert werden. Die notwendigen Daten auf dem Tab „Turnier-Daten“ sind weitgehend selbsterklärend.

Wichtig ist lediglich, dass die Daten eines neuen Turnier-Sets nicht gespeichert werden, wenn kein Turnier-Name vergeben wurde. Damit also die sonstigen erfassten Daten vor dem Wechsel auf einen anderen Tab, auf dem man dann aber auch gar nichts eingeben kann, oder beim Schließen des Dialogs nicht verloren gehen, muss man vorher den Button „Sichern“ nutzen.

Sobald ein Turnier-Set einmal gespeichert wurde, werden alle Änderungen beim Wechsel zwischen den Tabs automatisch gesichert.

## Combo-Box „Turnier-Serie“

Über dieses Feld wird gesteuert, ob das Pokerspiel Teil einer Serie ist. Daher kann hier zum einen durch Erfassung eines neuen Namens eine neue Serie erstellt werden zum anderen wird durch Auswahl einer bestehenden Serie aus der Klappleiste festgelegt, dass die Ergebnisse dieses Turniers bei Erstellung einer Rangliste für die Serie berücksichtigt werden sollen.

Näheres siehe unter Menü „Allgemein-> Auswertungen“.

## Gruppe „Punkte-/ Gewinnverteilung“

Die Struktur für die Gewinn- also Preisgeld- bzw. Punkte-Verteilung wird im Tab „Punkte / Gewinn“ eingestellt. Sie kann dort frei gewählt werden.

Über das Ankreuzen des Feldes „Anzeige“ in der Gruppe „Punkte-/ Gewinnverteilung“ wird hingegen gesteuert, ob im Timer-Panel überhaupt die Gruppe „Edit Prices“ bzw. „Edit Points“ angezeigt wird. Dies kann im Timer-Panel aber auch während des Turniers noch geändert werden.
Sofern die Anzeige angeschaltet ist, kann dann noch über die Radio-Buttons bestimmt werden, ob die Punkte-Verteilung oder die Gewinn-Verteilung  angezeigt werden soll. Diese Festlegung kann im Timer-Panel nicht mehr verändert werden, da ein Wechsel während eines Turniers keinen Sinn macht, da entweder das eine oder das andere das Ziel des Turniers ist, auch wenn im Tab „Punkte / Gewinn“ beides parallel hinterlegt werden kann.

### Button „Öffnen“

Dies ist der gleiche Auswahl-Dialog für ein bestehendes Turnier-Set wie auf dem Hauptfenster. Nach dem Öffnen des Turnier-Sets können alle Einstellungen auf den Tabs angepasst werden.

## Gruppe „Neu“

### Button „Blanko“

Sollte ein Turnier-Set geladen sein, wird dieses gespeichert und geschlossen. Danach werden alle  Erfassungsfelder gelöscht und zur Eingabe für ein neues Turnier-Set freigeschaltet.

### Button „Vorlage“

Es wird der gleich Auswahl-Dialog wie beim Button „Öffnen“ gezeigt. Allerdings wird nicht das gewählte Turnier-Set in Gänze geladen, sondern es wird ein neues Turnier-Set erstellt, bei dem folgende Daten aus dem alten Turnier-Set übernommen werden:

* Tab Turnier-Daten: Turnier-Name, Turnier-Serie, Buy-In,  Re-Buy, Add-On und Auswahl für das Feld „Anzeige“ bzw. Punkte/Gewinn. Das Turnier-Datum wird mit dem aktuellen Datum vorbelegt.
* Tab Blinds-Struktur: Die gesamte alte Struktur wird übernommen.
* Tab Punkte / Gewinn: Die Punkte- und Gewinn-Verteilung des alten Turnier-Sets wird komplett übernommen.
* Tab Chips: Die Bilder der Chips sowie ihre jeweilige Anzeige-Option werden übernommen.
* Tab Logo: Auch das Logo des Veranstalters wird übernommen.

Alle anderen Daten, also insbesondere welche Spieler und Dealer nehmen teil sowie die gewünschte Sitzverteilung, müssen in den Tabs dann neu selbst belegt werden.
