<link href="styles/styles.css" rel="stylesheet"></link>

# Dialog „Einstellungen“

![Dialog Einstellungen](img/setupcolors.jpg)

Hier können generelle Einstellungen für das Programm gemacht werden. Der Aufruf ist auch mit „Alt“ (Windows) bzw. „Cmd“ (Mac) und Taste Komma (,) möglich.
Da die Timer-Panels nicht modal laufen, kann der Einstellungen-Dialog parallel aufgerufen werden. So ist es möglich, insbesondere die Farben anzupassen und das Ergebnis sofort im jeweiligen Timer-Panel zu sehen. Ebenso können dann gleich auch die Töne für Blind-Wechsel etc. geändert werden, ohne dass das Turnier bzw. der Single-Table unterbrochen werden muss.

## Gruppe „Timer-Panel - Farben - Farben“

Im bescheidenen Umfang kann man an dieser Stelle die Farben für verschiedene Elemente der Timer-Panels einstellen.
Über den Button „Reset“ werden die Standard-Farben für das jeweilige Timer-Panel wiederhergestellt. Die vorherigen Einstellungen gehen dabei verloren, auch wenn man den Dialog anschließend über Button „Abbruch“ verlässt.
