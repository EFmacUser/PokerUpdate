<link href="styles/styles.css" rel="stylesheet"></link>

# Hauptfenster

![Programmfesnter](img/main.jpg)

Bevor der Timer für das Main-Event gestartet werden kann, muss immer erst ein Turnier-Set erstellt bzw. geöffnet werden. Dies ist direkt vom Hauptfenster möglich.  

Ein Turnier-Set für ein Main-Event besteht aus folgenden Teilen:

* Allgemeine Daten (Pflicht)
* Blind-Struktur (Option / Pflicht)
* Spieler-Liste (Option)
* Dealer-Liste (Option)
* Sitzverteilung (Option)
* Punkte-Verteilung (Option)
* Chips-Anzeige (Option)
* Logo-Anzeige (Option)

## Button "Öffnen"

Über den Button „Öffnen“ wird der Dialog „Turnier auswählen“ gestartet. Hier kann ein bereits im Vorfeld erstelltes / bearbeitetes Turnier-Set geladen werden.  

## Button „Neu“

Ein gänzlich neues Pokerspiel wird über den Button „Neu“ konfiguriert. Damit wird dann der Dialog für die Turnier-Einstellungen aber ohne Vorgaben aufgerufen.

## Button „Anpassen“

Das geladene Turnier kann vor dem Start noch über den Button „Anpassen“ oder auch über das Menü „Turnier-> Einstellungen“ bearbeitet werden, siehe Kapitel „Turnier-Einstellungen“

## Button „Schließen“

Dieser Button wird nur im Ausnahmefall benötigt: Das aktuell geladene Turnier wird im Öffnen-Dialog automatisch ausgeblendet. Daher kann dieses auch nicht als Kopiervorlage genutzt werden, wenn ein neues Turnier auf dieser Basis erstellt werden soll. Um nicht das Programm beenden zu müssen, kann das Programm hier quasi zurückgesetzt werden. Dadurch kann das Turnier-Set wieder im Öffnen-Dialog ausgewählt werden.

## Button „Start“

Sobald über den Button „Öffnen“ ein Turnier-Set ausgewählt oder mit Button „Neu“ ein neues Set erstellt wurde, kann das Pokerspiel im Hauptfenster über den Button „Start“ mit den so vorher eingestellten Werten begonnen werden, da dann das eigentliche Timer-Panel aufgerufen wird.

## Statuszeile

![Statusbar](img/statusbar.jpg)

In der Statuszeile werden immer die IP-Adresse sowie der Port angezeigt, über die der im PokerTimer integrierte Web-Server mit einem beliebigen Browser erreicht werden kann.  

Adresse und Port werden beim Start des Programms aus den Einstellungen geladen, haben also den Status des letzten Programmlaufs. Wenn im Einstellungen-Dialog der Port manuell geändert wurde, muss der PokerTimer beendet und neu gestartet werden. Erst danach werden die Änderungen aktiv, also der Web-Server wird über die neue Adress-Port-Kombination erreicht.

Sofern ein Update im Internet vorliegt und der Download gestartet wurde, wird hier im Feld neben dem Port der Fortschritt des Downloads in Prozent angezeigt.