<link href="styles/styles.css" rel="stylesheet"></link>

# Dialog "Punkte-Struktur kopieren"

![Struktur kopieren](img/pointsmgm.jpg)

Über den Dialog kann die Punkte-Struktur eines beliebigen alten Turnier-Sets als Vorlage für das aktuell zu bearbeitende ausgewählt werden.

Beim Durchscrollen der Turnier-Sets wird im rechten Teil des Fensters die zugehörige Punkte-Struktur angezeigt.

Eine Suche nach Datum, Turnier-Name oder Serie ist auch möglich.

**Achtung:** Bei Auswahl der Punkte-Struktur wird eine ggf. bis dahin erstellte Struktur ohne Nachfrage gelöscht und durch diese ersetzt!
