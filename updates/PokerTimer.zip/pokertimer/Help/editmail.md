<link href="styles/styles.css" rel="stylesheet"></link>

# Dialog "Spieler anpassen bzw. erstellen"

Mit dem Dialog kann entweder ein bestehender Spieler aus der Datenbank geändert oder ein gänzlich neuer Spieler erstellt werden.

## Bestehenden Spieler aus Mail anpassen

![Blindstruktur](img/mailedit1.jpg)

In der ersten Zeile werden die Daten der aktuell ausgewählten Mail angezeigt. Die zweite Zeile zeigt die Daten des Spielers aus der Datenbank, der gerade ausgewählt war.

Um die Daten der eines Mail-Feldes, z.B. den Vornamen, in die Spieler-Datenbank zu übernehmen, wählt man in der zweiten Zeile das Feld mit dem Vornamen aus der Datenbank aus und drückt den Button "Kopieren". Es reicht wenn das Feld den Fokus hat, also rot umrandet ist.Es muss nicht zu editieren aktiviert worden sein, was man an der blauen Selektion des Textes erkennt. Der Kopier-Vorgang kann nach Bedarf auch mit den anderen Feldern gemacht werden.
Es ist aber auch möglich, ein Feld zum Editieren auszuwählen, also dass der Text blau selektiert ist, und es dann manuell zu korrigieren.

## Neuen Spieler aus Mail erstellen

![Blindstruktur](img/mailedit2.jpg)

In der ersten Zeile werden die Daten der aktuell ausgewählten Mail angezeigt. Mit den gleichen Daten wird auch die zweite Zeile vorbelegt, so dass daraus direkt ein neuer Spieler für die Datenbank erzeugt werden kann. Es können aber alle Felder noch manuell (nach)bearbeitet werden, so denn nötig.