SELECT 
                 ID_Mail_Server 
                FROM 
                  Mails 
                WHERE 
                  (ID_Game = 478) AND
                  (ID_Mail_Server = "dddd"